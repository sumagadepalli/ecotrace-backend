import { SmartBin, BinStatus } from '../../types/bin';
import { DetectionEvent } from '../../types/detection';
import { RecyclingFacility } from '../../types/agency';
import { MunicipalAlert, AlertStatus } from '../../types/alert';
import { OperationalAuditTrail } from '../../types/audit';
import { INITIAL_BINS, INITIAL_FACILITIES, INITIAL_DETECTIONS, INITIAL_ALERTS, MOCK_AUDIT_TRAILS } from './mockData';

class MockDataStore {
  private bins: SmartBin[] = [...INITIAL_BINS];
  private facilities: RecyclingFacility[] = [...INITIAL_FACILITIES];
  private detections: DetectionEvent[] = [...INITIAL_DETECTIONS];
  private alerts: MunicipalAlert[] = [...INITIAL_ALERTS];
  private auditTrails: Record<string, OperationalAuditTrail> = { ...MOCK_AUDIT_TRAILS };

  // --- BINS ---
  public getBins(): SmartBin[] {
    return [...this.bins];
  }

  public getBinById(id: string): SmartBin | undefined {
    return this.bins.find((b) => b.id.toLowerCase() === id.toLowerCase());
  }

  public updateBinStatus(id: string, status: BinStatus): SmartBin | undefined {
    const bin = this.getBinById(id);
    if (bin) {
      bin.status = status;
      bin.lastUpdated = 'Just now';
    }
    return bin;
  }

  public dispatchBinCollection(id: string): SmartBin | undefined {
    const bin = this.getBinById(id);
    if (bin) {
      bin.status = 'operational';
      bin.overallFill = 15;
      bin.compartments.dry.fillPercent = 10;
      bin.compartments.dry.status = 'normal';
      bin.compartments.wet.fillPercent = 12;
      bin.compartments.wet.status = 'normal';
      bin.compartments.ewaste.fillPercent = 8;
      bin.compartments.ewaste.status = 'normal';
      bin.compartments.battery.fillPercent = 6;
      bin.compartments.battery.status = 'normal';
      bin.lastUpdated = 'Just now (Emptied)';

      // Auto-resolve any capacity alerts for this bin
      this.alerts.forEach((alt) => {
        if (alt.binId === id && alt.parameterName === 'Fill Level' && alt.status !== 'resolved') {
          alt.status = 'resolved';
          alt.severity = 'resolved';
          alt.resolutionHistory.push({
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'Dispatched collection emptied compartments',
            actor: 'Municipal Operations Desk',
            note: 'Capacity returned to 15% baseline.',
          });
        }
      });
    }
    return bin;
  }

  // --- DETECTIONS ---
  public getDetections(): DetectionEvent[] {
    return [...this.detections];
  }

  public getDetectionById(id: string): DetectionEvent | undefined {
    return this.detections.find((d) => d.id.toLowerCase() === id.toLowerCase());
  }

  public getDetectionsByBinId(binId: string): DetectionEvent[] {
    return this.detections.filter((d) => d.binId.toLowerCase() === binId.toLowerCase());
  }

  // --- RECYCLING FACILITIES ---
  public getFacilities(): RecyclingFacility[] {
    return [...this.facilities];
  }

  public getFacilityById(id: string): RecyclingFacility | undefined {
    return this.facilities.find((f) => f.id.toLowerCase() === id.toLowerCase());
  }

  // --- ALERTS ---
  public getAlerts(): MunicipalAlert[] {
    return [...this.alerts];
  }

  public getAlertById(id: string): MunicipalAlert | undefined {
    return this.alerts.find((a) => a.id.toLowerCase() === id.toLowerCase());
  }

  public updateAlertStatus(
    id: string,
    status: AlertStatus,
    actor: string = 'Municipal Officer',
    note?: string
  ): MunicipalAlert | undefined {
    const alert = this.getAlertById(id);
    if (alert) {
      alert.status = status;
      if (status === 'resolved') {
        alert.severity = 'resolved';
      }
      alert.resolutionHistory.push({
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        action: `Status marked as ${status.replace('_', ' ')}`,
        actor,
        note: note || (status === 'acknowledged' ? 'Incident acknowledged by operations desk.' : 'Marked resolved with verified operational note.'),
      });
    }
    return alert;
  }

  // --- AUDIT TRAIL ---
  public getAuditTrail(eventId: string): OperationalAuditTrail | undefined {
    return this.auditTrails[eventId];
  }
}

export const mockStore = new MockDataStore();
