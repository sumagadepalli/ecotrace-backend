import { SmartBin, BinStatus } from '../../types/bin';
import { mockStore } from '../mock/mockStorage';

// Simulated async delays to simulate realistic network behavior
const delay = (ms: number = 60) => new Promise((resolve) => setTimeout(resolve, ms));

export const binsApi = {
  async getBins(): Promise<SmartBin[]> {
    await delay();
    return mockStore.getBins();
  },

  async getBinById(id: string): Promise<SmartBin | undefined> {
    await delay();
    return mockStore.getBinById(id);
  },

  async updateBinStatus(id: string, status: BinStatus): Promise<SmartBin | undefined> {
    await delay();
    return mockStore.updateBinStatus(id, status);
  },

  async dispatchCollection(id: string): Promise<SmartBin | undefined> {
    await delay();
    return mockStore.dispatchBinCollection(id);
  },
};
