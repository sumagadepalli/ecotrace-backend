import { DetectionEvent } from '../../types/detection';
import { mockStore } from '../mock/mockStorage';

const delay = (ms: number = 60) => new Promise((resolve) => setTimeout(resolve, ms));

export const wasteApi = {
  async getDetections(): Promise<DetectionEvent[]> {
    await delay();
    return mockStore.getDetections();
  },

  async getDetectionById(id: string): Promise<DetectionEvent | undefined> {
    await delay();
    return mockStore.getDetectionById(id);
  },

  async getDetectionsByBin(binId: string): Promise<DetectionEvent[]> {
    await delay();
    return mockStore.getDetectionsByBinId(binId);
  },
};
