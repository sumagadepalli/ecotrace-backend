import { OperationalAuditTrail } from '../../types/audit';
import { mockStore } from '../mock/mockStorage';

const delay = (ms: number = 60) => new Promise((resolve) => setTimeout(resolve, ms));

export const auditApi = {
  async getAuditTrail(eventId: string): Promise<OperationalAuditTrail | undefined> {
    await delay();
    return mockStore.getAuditTrail(eventId);
  },
};
