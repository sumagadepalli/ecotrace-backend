import { MunicipalAlert, AlertStatus } from '../../types/alert';
import { mockStore } from '../mock/mockStorage';

const delay = (ms: number = 60) => new Promise((resolve) => setTimeout(resolve, ms));

export const alertsApi = {
  async getAlerts(): Promise<MunicipalAlert[]> {
    await delay();
    return mockStore.getAlerts();
  },

  async getAlertById(id: string): Promise<MunicipalAlert | undefined> {
    await delay();
    return mockStore.getAlertById(id);
  },

  async updateStatus(
    id: string,
    status: AlertStatus,
    actor?: string,
    note?: string
  ): Promise<MunicipalAlert | undefined> {
    await delay();
    return mockStore.updateAlertStatus(id, status, actor, note);
  },
};
