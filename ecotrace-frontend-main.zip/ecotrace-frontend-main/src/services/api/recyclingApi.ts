import { RecyclingFacility } from '../../types/agency';
import { mockStore } from '../mock/mockStorage';

const delay = (ms: number = 60) => new Promise((resolve) => setTimeout(resolve, ms));

export const recyclingApi = {
  async getFacilities(): Promise<RecyclingFacility[]> {
    await delay();
    return mockStore.getFacilities();
  },

  async getFacilityById(id: string): Promise<RecyclingFacility | undefined> {
    await delay();
    return mockStore.getFacilityById(id);
  },

  async getFacilitiesForPathway(pathway: string): Promise<RecyclingFacility[]> {
    await delay();
    const all = mockStore.getFacilities();
    if (!pathway || pathway === 'all') return all;
    return all.filter((f) => f.acceptedPathways.includes(pathway as any));
  },
};
