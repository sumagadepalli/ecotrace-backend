import { PathwayType } from './bin';

export interface RecommendationBasis {
  detectedWaste: string;
  capabilityStatus: 'Accepted' | 'Restricted' | 'Ineligible';
  verificationStatus: 'Verified' | 'Pending Audit' | 'Unverified';
  distanceKm: number;
  routePriorityText: string;
  suitabilityScoreSummary: string;
}

export interface RecyclingFacility {
  id: string; // e.g. "FAC-PN-001"
  name: string;
  verified: boolean;
  licenseNumber: string;
  authority: string; // e.g. "State Pollution Control Board Authorized"
  lat: number;
  lng: number;
  address: string;
  contactPerson: string;
  contactPhone: string;
  acceptedPathways: PathwayType[];
  acceptedCategories: string[]; // e.g. ["Consumer PCB", "Development PCB", "Copper-bearing materials"]
  processingCapacityTonsMonth: number;
  priorityForDetection?: 'Recommended' | 'Alternative' | 'Ineligible';
  distanceFromSelectedKm?: number;
  recommendationBasis?: RecommendationBasis;
}
