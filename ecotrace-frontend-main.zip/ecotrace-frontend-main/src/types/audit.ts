export interface AuditStep {
  stepIndex: number;
  time: string;
  event: string;
  status: 'Completed' | 'Verified' | 'Pending' | 'Flagged';
  evidenceReference: string;
  conciseReason: string;
}

export interface OperationalAuditTrail {
  eventId: string;
  binId: string;
  timestamp: string;
  steps: AuditStep[];
}
