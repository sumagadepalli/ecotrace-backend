import { PathwayType } from './bin';

export type DetectionStatus =
  | 'Recommendation ready'
  | 'Warning'
  | 'Recorded'
  | 'Analysis unavailable';

export interface RecoverableMaterial {
  name: string;
  chemicalSymbol?: string;
  estimatedConcentration: string;
  potentialApplication: string;
}

export interface KnowledgeMetadata {
  sourceName: string;
  version: string;
  referenceDate: string;
  curatorAgency: string;
}

export interface RecommendedRecoveryMethod {
  categoryName: string;
  technicalCategory: string;
  operationalDescription: string;
  safetyConsiderations: string;
}

export interface DetectionEvent {
  id: string; // e.g. "EVT-2026-0912-0042"
  binId: string;
  zone: string;
  timestamp: string;
  wasteType: PathwayType;
  detectedCategory: string; // e.g. "Consumer PCB", "Development PCB", "Li-ion Cell"
  confidencePercent: number; // e.g. 94
  status: DetectionStatus;
  componentGroup: string; // e.g. "Consumer electronics multilayer PCB"
  recoverableMaterials: RecoverableMaterial[];
  knowledgeBase: KnowledgeMetadata;
  recoveryMethod: RecommendedRecoveryMethod;
  recommendedAgencyId: string | null;
  recommendationReasonSummary: string;
  labels: {
    detected: string;
    calculated: string;
    estimated: string;
    recommended: string;
  };
}
