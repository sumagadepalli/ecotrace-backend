export type BinStatus =
  | 'operational'
  | 'near_capacity'
  | 'collection_required'
  | 'environmental_warning'
  | 'offline';

export type PathwayType = 'dry' | 'wet' | 'ewaste' | 'battery';

export interface CompartmentStatus {
  pathway: PathwayType;
  label: string;
  fillPercent: number;
  status: 'normal' | 'attention' | 'critical';
  lastEmptyTimestamp: string;
}

export interface EnvironmentalReadings {
  batteryCompartmentTemp: number | null; // in °C. null if no reading
  batteryCompartmentHumidity: number | null; // in %. null if no reading
  wetCompartmentGasIndex: 'normal' | 'elevated' | null; // null if no reading
  gasIndexRawValue?: number | null;
  riskStatus: 'normal' | 'warning' | 'critical';
  riskExplanation: string;
  sensorModel: string; // e.g. "DHT11 Threshold Sensor"
  lastPingTimestamp: string | null;
}

export interface SmartBin {
  id: string; // e.g. "ECO-PN-HH-0001"
  zone: string; // e.g. "Shivajinagar Zone"
  ward: string; // e.g. "Ward 07 - Central Pune"
  locationName: string; // e.g. "FC Road Civic Plaza"
  lat: number;
  lng: number;
  overallFill: number; // percentage
  status: BinStatus;
  lastUpdated: string;
  compartments: {
    dry: CompartmentStatus;
    wet: CompartmentStatus;
    ewaste: CompartmentStatus;
    battery: CompartmentStatus;
  };
  environment: EnvironmentalReadings;
  hardwareVersion: string;
  installedAt: string;
}
