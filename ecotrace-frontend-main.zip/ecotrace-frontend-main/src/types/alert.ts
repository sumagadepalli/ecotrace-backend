export type AlertSeverity = 'critical' | 'warning' | 'resolved';

export type AlertStatus = 'open' | 'acknowledged' | 'in_progress' | 'resolved';

export interface AlertHistoryEntry {
  timestamp: string;
  action: string;
  actor: string;
  note?: string;
}

export interface MunicipalAlert {
  id: string; // e.g. "ALT-2026-0819"
  severity: AlertSeverity;
  headline: string;
  description: string;
  binId: string;
  zone: string;
  locationName: string;
  timestamp: string;
  status: AlertStatus;
  triggerCondition: string; // e.g. "Battery compartment temperature reached 47.2°C (threshold: 45.0°C)"
  parameterName: 'Temperature' | 'Humidity' | 'Fill Level' | 'Gas Index' | 'Connectivity';
  observedValue: string;
  thresholdValue: string;
  resolutionHistory: AlertHistoryEntry[];
}
