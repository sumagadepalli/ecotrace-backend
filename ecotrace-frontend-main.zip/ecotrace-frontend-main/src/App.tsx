import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from './components/layout/AppLayout';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Overview } from './pages/Overview';
import { SmartBins } from './pages/SmartBins';
import { BinDetail } from './pages/BinDetail';
import { WasteIntelligence } from './pages/WasteIntelligence';
import { WasteEventDetail } from './pages/WasteEventDetail';
import { RecyclingNetwork } from './pages/RecyclingNetwork';
import { Alerts } from './pages/Alerts';
import { AdminSettings } from './pages/AdminSettings';

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />

        {/* Authenticated Municipal Console Routes */}
        <Route element={<AppLayout />}>
          <Route path="/overview" element={<Overview />} />
          <Route path="/bins" element={<SmartBins />} />
          <Route path="/bins/:id" element={<BinDetail />} />
          <Route path="/smart-bins" element={<SmartBins />} />
          <Route path="/smart-bins/:id" element={<BinDetail />} />
          <Route path="/waste-intelligence" element={<WasteIntelligence />} />
          <Route path="/waste-intelligence/:id" element={<WasteEventDetail />} />
          <Route path="/recycling-network" element={<RecyclingNetwork />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/admin" element={<AdminSettings />} />
        </Route>

        {/* Catch-all fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
