import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Lock, Building2, Mail, ArrowRight } from 'lucide-react';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [organization, setOrganization] = useState('Pune Municipal Corporation (PMC)');
  const [email, setEmail] = useState('s.deshmukh@pmc.gov.in');
  const [password, setPassword] = useState('••••••••••••');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      navigate('/overview');
    }, 350);
  };

  const handleQuickDemo = () => {
    setOrganization('Pune Municipal Corporation (Ward 07)');
    setEmail('s.deshmukh@pmc.gov.in');
    setPassword('MunicipalOps2026!');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-4xl bg-white rounded-lg border border-slate-200 shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-2">
        {/* Left Side: Municipal Authority Branding */}
        <div className="bg-slate-900 text-slate-200 p-8 sm:p-10 flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-800">
          <div>
            <div className="flex items-center gap-2.5 mb-8">
              <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center text-white font-bold text-base">
                B
              </div>
              <span className="font-bold text-lg tracking-tight text-white">
                BRUNOXBIN
              </span>
            </div>

            <h1 className="text-xl font-bold text-white tracking-tight leading-snug mb-3">
              Municipal Waste Monitoring & E-Waste Intelligence
            </h1>

            <p className="text-xs text-slate-400 leading-relaxed">
              Authorized municipal operations portal for real-time asset telemetry, environmental safety monitoring, and certified downstream recycling facility dispatch.
            </p>
          </div>

          <div className="pt-8 border-t border-slate-800/80 mt-8 space-y-3">
            <div className="flex items-start gap-2.5 text-xs text-slate-300">
              <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <span>Restricted access: Authorized civic personnel and zonal solid waste supervisors only.</span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              System Release: v2.4-Municipal · Audit Protocol Active
            </div>
          </div>
        </div>

        {/* Right Side: Official Login Form */}
        <div className="p-8 sm:p-10 flex flex-col justify-center">
          <div className="mb-6">
            <h2 className="text-lg font-bold text-slate-900 tracking-tight">
              Sign In
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Enter your official municipal credentials to access the console.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Organization / Municipal Body
              </label>
              <div className="relative">
                <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={organization}
                  onChange={(e) => setOrganization(e.target.value)}
                  placeholder="e.g. Pune Municipal Corporation"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Official Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@authority.gov.in"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-900 font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-2 px-4 rounded bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold shadow-xs focus:outline-hidden focus:ring-2 focus:ring-blue-600 transition-colors flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <span>Authenticating with Municipal Gateway...</span>
              ) : (
                <>
                  <span>Sign in to Console</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Pre-fill for reviewer */}
          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">Evaluation preview:</span>
            <button
              type="button"
              onClick={handleQuickDemo}
              className="text-[11px] font-medium text-blue-700 hover:text-blue-900 underline underline-offset-2"
            >
              Fill Demo Credentials
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
