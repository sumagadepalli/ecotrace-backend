import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Calendar,
  MapPin,
  ExternalLink,
  ShieldCheck,
  Truck,
  CheckCircle2,
  Clock,
  FileCheck,
  AlertCircle,
} from 'lucide-react';
import { DetectionEvent } from '../types/detection';
import { RecyclingFacility } from '../types/agency';
import { OperationalAuditTrail } from '../types/audit';
import { wasteApi } from '../services/api/wasteApi';
import { recyclingApi } from '../services/api/recyclingApi';
import { auditApi } from '../services/api/auditApi';
import { StatusBadge } from '../components/common/StatusBadge';
import { CategoryPill } from '../components/common/CategoryPill';
import { ProvenanceTag } from '../components/intelligence/ProvenanceTag';
import { MaterialEstimate } from '../components/intelligence/MaterialEstimate';
import { RecommendationBasisCard } from '../components/intelligence/RecommendationBasis';

export const WasteEventDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<DetectionEvent | null>(null);
  const [agency, setAgency] = useState<RecyclingFacility | null>(null);
  const [audit, setAudit] = useState<OperationalAuditTrail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEventData = async () => {
      if (!id) return;
      setLoading(true);
      const eventData = await wasteApi.getDetectionById(id);
      if (eventData) {
        setEvent(eventData);
        if (eventData.recommendedAgencyId) {
          const agencyData = await recyclingApi.getFacilityById(eventData.recommendedAgencyId);
          setAgency(agencyData || null);
        }
        const auditData = await auditApi.getAuditTrail(id);
        setAudit(auditData || null);
      }
      setLoading(false);
    };
    fetchEventData();
  }, [id]);

  if (loading) {
    return (
      <div className="p-12 text-center text-xs text-slate-500 font-medium">
        Loading operational intelligence record {id}...
      </div>
    );
  }

  if (!event) {
    return (
      <div className="space-y-4">
        <Link
          to="/waste-intelligence"
          className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline font-medium"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Waste Intelligence
        </Link>
        <div className="border border-slate-200 rounded-md bg-white p-8 text-center text-xs text-slate-600">
          Detection record "{id}" was not found.
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Navigation & Header */}
      <div>
        <Link
          to="/waste-intelligence"
          className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 font-medium mb-1.5 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Intelligence Archive
        </Link>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              {event.wasteType === 'ewaste' ? 'E-Waste Event' : 'Waste Event'}: {event.id}
            </h1>
            <StatusBadge status={event.status} />
          </div>
          <div className="text-xs text-slate-500 font-mono">
            Recorded: {event.timestamp}
          </div>
        </div>
      </div>

      {/* SECTION 1: DETECTION SPECIFICATION */}
      <section aria-labelledby="detection-heading" className="border border-slate-200 rounded-md bg-white p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <h2 id="detection-heading" className="text-sm font-semibold text-slate-900">
              Detection
            </h2>
            <ProvenanceTag kind="DETECTED" />
          </div>
          <span className="font-mono text-xs text-slate-500">
            Event Ref: {event.id}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <div className="text-xs text-slate-500">Detected Category</div>
            <div className="text-base font-bold text-slate-900 mt-0.5">
              {event.detectedCategory}
            </div>
          </div>

          <div>
            <div className="text-xs text-slate-500">Model Confidence</div>
            <div className="text-base font-bold font-mono text-slate-900 mt-0.5">
              {event.confidencePercent}%
            </div>
          </div>

          <div>
            <div className="text-xs text-slate-500">Reporting Bin</div>
            <div className="text-base font-bold font-mono text-blue-700 mt-0.5">
              <Link to={`/bins/${event.binId}`} className="hover:underline inline-flex items-center gap-1">
                <span>{event.binId}</span>
                <ExternalLink className="w-3 h-3" />
              </Link>
            </div>
            <div className="text-[11px] text-slate-500">{event.zone}</div>
          </div>

          <div>
            <div className="text-xs text-slate-500">Waste Pathway</div>
            <div className="mt-1">
              <CategoryPill pathway={event.wasteType} />
            </div>
          </div>
        </div>

        {/* Provenance Grounding Breakdown */}
        <div className="mt-5 pt-3 border-t border-slate-100 bg-slate-50/70 -mx-5 -mb-5 p-4 rounded-b-md">
          <div className="text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-2">
            Provenance Trail & Grounding Labels
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="text-slate-700">
              <span className="font-mono text-[10px] font-bold text-blue-800 bg-blue-100 px-1 py-0.5 rounded mr-1.5">DETECTED</span>
              {event.labels.detected}
            </div>
            <div className="text-slate-700">
              <span className="font-mono text-[10px] font-bold text-indigo-800 bg-indigo-100 px-1 py-0.5 rounded mr-1.5">CALCULATED</span>
              {event.labels.calculated}
            </div>
            <div className="text-slate-700">
              <span className="font-mono text-[10px] font-bold text-amber-900 bg-amber-100 px-1 py-0.5 rounded mr-1.5">ESTIMATED</span>
              {event.labels.estimated}
            </div>
            <div className="text-slate-700">
              <span className="font-mono text-[10px] font-bold text-emerald-900 bg-emerald-100 px-1 py-0.5 rounded mr-1.5">RECOMMENDED</span>
              {event.labels.recommended}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: MATERIAL INTELLIGENCE */}
      <section aria-labelledby="materials-heading">
        <MaterialEstimate
          componentGroup={event.componentGroup}
          materials={event.recoverableMaterials}
          knowledgeBase={event.knowledgeBase}
        />
      </section>

      {/* SECTION 3: RECOMMENDED RECOVERY METHOD */}
      <section aria-labelledby="recovery-heading" className="border border-slate-200 rounded-md bg-white p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <h2 id="recovery-heading" className="text-sm font-semibold text-slate-900">
              Recommended Recovery Method
            </h2>
            <ProvenanceTag kind="RECOMMENDED" />
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {event.recoveryMethod.technicalCategory}
          </span>
        </div>

        <div className="space-y-3">
          <div>
            <div className="text-base font-bold text-slate-900">
              {event.recoveryMethod.categoryName}
            </div>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              {event.recoveryMethod.operationalDescription}
            </p>
          </div>

          <div className="p-3 rounded bg-amber-50/70 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Safety & Handling: </span>
              {event.recoveryMethod.safetyConsiderations}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: RECOMMENDED RECYCLING AGENCY & BASIS */}
      {agency && (
        <section aria-labelledby="agency-heading" className="space-y-4">
          <div className="border border-slate-200 rounded-md bg-white p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2 mb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 id="agency-heading" className="text-sm font-semibold text-slate-900">
                    Recommended Recycling Agency
                  </h2>
                  <ProvenanceTag kind="RECOMMENDED" />
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Nearest suitable facility holding active MPCB compliance license
                </p>
              </div>

              <Link
                to={`/recycling-network?bin=${event.binId}&facility=${agency.id}`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold shadow-2xs transition-colors"
              >
                <Truck className="w-3.5 h-3.5" />
                <span>View Route on Operational Map</span>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <div className="text-xs text-slate-500">Facility Name</div>
                <div className="text-sm font-bold text-slate-900 mt-0.5">
                  {agency.name}
                </div>
                <div className="mt-1">
                  <StatusBadge status={agency.verified ? 'Verified' : 'Unverified'} size="sm" />
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Distance from Bin {event.binId}</div>
                <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                  {agency.distanceFromSelectedKm} km
                </div>
                <div className="text-[11px] text-slate-500">Route-ranked transit distance</div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Accepted Materials</div>
                <div className="text-xs text-slate-800 font-medium mt-0.5">
                  {agency.acceptedCategories.join(' · ')}
                </div>
              </div>
            </div>

            {/* Recommendation Basis Breakdown */}
            <RecommendationBasisCard
              basis={agency.recommendationBasis}
              agencyName={agency.name}
              facilityAddress={agency.address}
              contactPhone={agency.contactPhone}
            />
          </div>
        </section>
      )}

      {/* SECTION 5: AUDIT TRAIL / OPERATIONAL HISTORY */}
      <section aria-labelledby="audit-heading" className="border border-slate-200 rounded-md bg-white p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <h2 id="audit-heading" className="text-sm font-semibold text-slate-900">
              Operational Event History &amp; Audit Trail
            </h2>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">
            Sequential Municipal Custody Log
          </span>
        </div>

        {audit ? (
          <div className="space-y-3">
            {audit.steps.map((step) => (
              <div
                key={step.stepIndex}
                className="flex items-start gap-3 text-xs p-2.5 rounded bg-slate-50/70 border border-slate-100"
              >
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-900 font-mono font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                  {step.stepIndex}
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold text-slate-900">{step.event}</span>
                    <span className="font-mono text-slate-500 text-[11px]">{step.time}</span>
                  </div>
                  <p className="text-slate-600 mt-0.5 leading-relaxed">{step.conciseReason}</p>
                  <div className="mt-1 text-[11px] font-mono text-slate-500">
                    Evidence reference: {step.evidenceReference}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-xs text-slate-500 p-4 border border-dashed border-slate-200 rounded text-center">
            Standard event sequence recorded at {event.timestamp}. Detailed step audit pending sync.
          </div>
        )}
      </section>
    </div>
  );
};
