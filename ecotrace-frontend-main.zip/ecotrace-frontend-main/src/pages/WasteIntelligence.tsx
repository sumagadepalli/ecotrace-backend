import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Cpu, ArrowRight, Eye } from 'lucide-react';
import { DetectionEvent } from '../types/detection';
import { wasteApi } from '../services/api/wasteApi';
import { StatusBadge } from '../components/common/StatusBadge';
import { CategoryPill } from '../components/common/CategoryPill';

export const WasteIntelligence: React.FC = () => {
  const [detections, setDetections] = useState<DetectionEvent[]>([]);
  const [searchBin, setSearchBin] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetections = async () => {
      setLoading(true);
      const data = await wasteApi.getDetections();
      setDetections(data);
      setLoading(false);
    };
    fetchDetections();
  }, []);

  const filteredDetections = detections.filter((item) => {
    const matchesBin =
      item.binId.toLowerCase().includes(searchBin.toLowerCase()) ||
      item.detectedCategory.toLowerCase().includes(searchBin.toLowerCase()) ||
      item.zone.toLowerCase().includes(searchBin.toLowerCase());

    if (!matchesBin) return false;
    if (typeFilter !== 'all' && item.wasteType !== typeFilter) return false;
    if (statusFilter !== 'all' && item.status !== statusFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">Waste Intelligence</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Review detected e-waste and battery events and their operational recommendations.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-md border border-slate-200 shadow-2xs">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchBin}
            onChange={(e) => setSearchBin(e.target.value)}
            placeholder="Filter by Bin ID, category, or zone..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
          />
        </div>

        {/* Pathway Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-[11px] font-medium text-slate-500 mr-1">Waste Pathway:</span>
          {[
            { key: 'all', label: 'All Pathways' },
            { key: 'ewaste', label: 'E-Waste' },
            { key: 'battery', label: 'Battery' },
            { key: 'dry', label: 'Dry' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setTypeFilter(tab.key)}
              className={`px-2.5 py-1 rounded text-xs font-medium border transition-colors ${
                typeFilter === tab.key
                  ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Intelligence Table */}
      <div className="border border-slate-200 rounded-md bg-white shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-2.5">Date / Time</th>
                <th className="px-4 py-2.5">Bin ID</th>
                <th className="px-4 py-2.5">Pathway</th>
                <th className="px-4 py-2.5">Detected Category</th>
                <th className="px-4 py-2.5">Confidence</th>
                <th className="px-4 py-2.5">Intelligence Status</th>
                <th className="px-4 py-2.5">Recovery Recommendation</th>
                <th className="px-4 py-2.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredDetections.length > 0 ? (
                filteredDetections.map((evt) => (
                  <tr key={evt.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-mono text-slate-600 whitespace-nowrap">
                      {evt.timestamp}
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-blue-700 whitespace-nowrap">
                      <Link to={`/bins/${evt.binId}`} className="hover:underline">
                        {evt.binId}
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <CategoryPill pathway={evt.wasteType} />
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900">
                      {evt.detectedCategory}
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-600">
                      {evt.confidencePercent}%
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={evt.status} size="sm" />
                    </td>
                    <td className="px-4 py-3 text-slate-600 truncate max-w-xs" title={evt.recoveryMethod?.categoryName}>
                      {evt.recoveryMethod?.categoryName || '—'}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <Link
                        to={`/waste-intelligence/${evt.id}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-500" />
                        <span>View</span>
                      </Link>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-500 text-xs">
                    No intelligence events match your current filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
          <span>Showing {filteredDetections.length} recorded waste events</span>
          <span className="font-mono text-[11px]">Municipal Evidence Archive v2.4</span>
        </div>
      </div>
    </div>
  );
};
