import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  AlertOctagon,
  CheckCircle2,
  Clock,
  ExternalLink,
  ShieldCheck,
  Check,
  UserCheck,
  Truck,
  Filter,
} from 'lucide-react';
import { MunicipalAlert, AlertSeverity, AlertStatus } from '../types/alert';
import { alertsApi } from '../services/api/alertsApi';
import { binsApi } from '../services/api/binsApi';
import { StatusBadge } from '../components/common/StatusBadge';
import { Modal } from '../components/common/Modal';

export const Alerts: React.FC = () => {
  const [alerts, setAlerts] = useState<MunicipalAlert[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [selectedAlert, setSelectedAlert] = useState<MunicipalAlert | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [resolutionNote, setResolutionNote] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchAlerts = async () => {
    setLoading(true);
    const data = await alertsApi.getAlerts();
    setAlerts(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  const filteredAlerts = alerts.filter((item) => {
    if (filter === 'all') return true;
    if (filter === 'critical') return item.severity === 'critical';
    if (filter === 'warning') return item.severity === 'warning';
    if (filter === 'resolved') return item.status === 'resolved';
    return true;
  });

  const handleAcknowledge = async () => {
    if (!selectedAlert) return;
    setIsUpdating(true);
    const updated = await alertsApi.updateStatus(
      selectedAlert.id,
      'acknowledged',
      'Municipal Operations Officer S. Deshmukh',
      'Incident acknowledged by Central Operations Desk. Assigned to zonal inspection queue.'
    );
    if (updated) {
      setSelectedAlert({ ...updated });
      await fetchAlerts();
    }
    setIsUpdating(false);
  };

  const handleResolve = async () => {
    if (!selectedAlert) return;
    setIsUpdating(true);
    const note = resolutionNote.trim() || 'Verified on site. Condition normal within configured thresholds.';
    const updated = await alertsApi.updateStatus(
      selectedAlert.id,
      'resolved',
      'Municipal Operations Officer S. Deshmukh',
      note
    );
    if (updated) {
      setSelectedAlert({ ...updated });
      setResolutionNote('');
      await fetchAlerts();
    }
    setIsUpdating(false);
  };

  const handleDispatchForAlert = async () => {
    if (!selectedAlert) return;
    setIsUpdating(true);
    await binsApi.dispatchCollection(selectedAlert.binId);
    const updated = await alertsApi.getAlertById(selectedAlert.id);
    if (updated) {
      setSelectedAlert({ ...updated });
    }
    await fetchAlerts();
    setIsUpdating(false);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">Operational Alerts</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Review active threshold breaches, capacity warnings, and physical sensor incidents.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-white p-2 rounded-md border border-slate-200 shadow-2xs text-xs">
        <span className="text-[11px] font-medium text-slate-500 mr-2 flex items-center gap-1">
          <Filter className="w-3.5 h-3.5" /> Filter Severity:
        </span>
        {[
          { key: 'all', label: `All Alerts (${alerts.length})` },
          { key: 'critical', label: `🔴 Critical (${alerts.filter((a) => a.severity === 'critical').length})` },
          { key: 'warning', label: `🟠 Warning (${alerts.filter((a) => a.severity === 'warning').length})` },
          { key: 'resolved', label: `🟢 Resolved (${alerts.filter((a) => a.status === 'resolved').length})` },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`px-3 py-1.5 rounded text-xs font-medium border transition-colors ${
              filter === tab.key
                ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Alerts Table */}
      <div className="border border-slate-200 rounded-md bg-white shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-2.5">Severity</th>
                <th className="px-4 py-2.5">Alert Condition</th>
                <th className="px-4 py-2.5">Bin ID &amp; Location</th>
                <th className="px-4 py-2.5">Trigger Reading</th>
                <th className="px-4 py-2.5">Time</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredAlerts.length > 0 ? (
                filteredAlerts.map((alert) => (
                  <tr key={alert.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge status={alert.severity} size="sm" />
                    </td>

                    <td className="px-4 py-3 font-medium text-slate-900">
                      <div>{alert.headline}</div>
                      <div className="text-[11px] text-slate-500 font-normal truncate max-w-md mt-0.5">
                        {alert.description}
                      </div>
                    </td>

                    <td className="px-4 py-3 whitespace-nowrap">
                      <Link
                        to={`/bins/${alert.binId}`}
                        className="font-mono font-bold text-blue-700 hover:underline"
                      >
                        {alert.binId}
                      </Link>
                      <div className="text-[11px] text-slate-500">{alert.zone}</div>
                    </td>

                    <td className="px-4 py-3 whitespace-nowrap font-mono text-[11px] text-slate-700">
                      {alert.observedValue} (limit: {alert.thresholdValue})
                    </td>

                    <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-500 text-[11px]">
                      {alert.timestamp}
                    </td>

                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge status={alert.status} size="sm" />
                    </td>

                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button
                        onClick={() => {
                          setSelectedAlert(alert);
                          setModalOpen(true);
                        }}
                        className="px-2.5 py-1 text-xs font-semibold rounded bg-blue-700 hover:bg-blue-800 text-white shadow-2xs"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500 text-xs">
                    No alerts in this view. All monitored bins are currently operating within configured thresholds.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* INSPECTION MODAL / DRAWER */}
      {selectedAlert && (
        <Modal
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          title={`Alert Inspection: ${selectedAlert.id}`}
          subtitle={`Reported for ${selectedAlert.binId} (${selectedAlert.zone})`}
          maxWidth="lg"
        >
          <div className="space-y-4">
            {/* Status & Severity Bar */}
            <div className="flex items-center justify-between p-3 rounded bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2">
                <StatusBadge status={selectedAlert.severity} />
                <span className="text-xs text-slate-500 font-mono">
                  Param: {selectedAlert.parameterName}
                </span>
              </div>
              <StatusBadge status={selectedAlert.status} />
            </div>

            {/* Trigger Condition & Explanation */}
            <div className="border border-slate-200 rounded p-3.5 bg-white space-y-2 text-xs">
              <div className="font-semibold text-slate-900 text-sm">
                {selectedAlert.headline}
              </div>
              <p className="text-slate-600 leading-relaxed">
                {selectedAlert.description}
              </p>
              <div className="mt-2 pt-2 border-t border-slate-100 grid grid-cols-2 gap-2 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500">Observed Value: </span>
                  <span className="font-bold text-slate-900">{selectedAlert.observedValue}</span>
                </div>
                <div>
                  <span className="text-slate-500">Configured Threshold: </span>
                  <span className="font-bold text-slate-900">{selectedAlert.thresholdValue}</span>
                </div>
              </div>
              <div className="text-[11px] text-slate-500 font-mono">
                Exact Trigger: {selectedAlert.triggerCondition}
              </div>
            </div>

            {/* Resolution History */}
            <div className="border border-slate-200 rounded p-3.5 bg-white">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-2">
                Operational Resolution History
              </h4>
              <div className="space-y-2">
                {selectedAlert.resolutionHistory.map((item, idx) => (
                  <div key={idx} className="p-2 rounded bg-slate-50 border border-slate-100 text-xs">
                    <div className="flex items-center justify-between text-slate-800 font-medium">
                      <span>{item.action}</span>
                      <span className="font-mono text-[11px] text-slate-500">{item.timestamp}</span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">By: {item.actor}</div>
                    {item.note && (
                      <div className="text-[11px] text-blue-900 mt-1 italic">
                        "{item.note}"
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Operational Action Controls */}
            {selectedAlert.status !== 'resolved' && (
              <div className="border-t border-slate-200 pt-3 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                  Take Operational Action
                </h4>

                <div className="flex flex-wrap items-center gap-2">
                  {selectedAlert.status === 'open' && (
                    <button
                      onClick={handleAcknowledge}
                      disabled={isUpdating}
                      className="px-3 py-1.5 rounded bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>Acknowledge Incident</span>
                    </button>
                  )}

                  {selectedAlert.parameterName === 'Fill Level' && (
                    <button
                      onClick={handleDispatchForAlert}
                      disabled={isUpdating}
                      className="px-3 py-1.5 rounded bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>Dispatch Collection Vehicle</span>
                    </button>
                  )}

                  <Link
                    to={`/bins/${selectedAlert.binId}`}
                    className="px-3 py-1.5 rounded border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium shadow-2xs transition-colors flex items-center gap-1.5"
                  >
                    <span>Inspect Bin Telemetry</span>
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>

                {/* Resolve with note */}
                <div className="pt-2 border-t border-slate-100">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Operational Resolution Note:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={resolutionNote}
                      onChange={(e) => setResolutionNote(e.target.value)}
                      placeholder="e.g. Field team replaced battery seal; sensor returned to 28°C."
                      className="flex-1 text-xs px-3 py-1.5 rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                    />
                    <button
                      onClick={handleResolve}
                      disabled={isUpdating}
                      className="px-3.5 py-1.5 rounded bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark Resolved</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setModalOpen(false)}
                className="px-3 py-1.5 rounded border border-slate-300 text-slate-700 text-xs font-medium hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
