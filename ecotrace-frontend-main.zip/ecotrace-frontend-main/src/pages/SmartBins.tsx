import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, RefreshCw, Eye } from 'lucide-react';
import { SmartBin, BinStatus } from '../types/bin';
import { binsApi } from '../services/api/binsApi';
import { StatusBadge } from '../components/common/StatusBadge';
import { ProgressBar } from '../components/common/ProgressBar';

export const SmartBins: React.FC = () => {
  const [bins, setBins] = useState<SmartBin[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  const fetchBins = async () => {
    setLoading(true);
    const data = await binsApi.getBins();
    setBins(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchBins();
  }, []);

  const filteredBins = bins.filter((bin) => {
    const matchesSearch =
      bin.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bin.zone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bin.locationName.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (statusFilter === 'all') return true;
    if (statusFilter === 'healthy') return bin.status === 'operational';
    return bin.status === statusFilter;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">Smart Bins</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Monitor bin status, fill levels, and environmental readings.
        </p>
      </div>

      {/* Control Bar: Search & Status Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-md border border-slate-200 shadow-2xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search bin ID, zone, or location..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-900"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-[11px] font-medium text-slate-500 mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Status:
          </span>
          {[
            { key: 'all', label: 'All Bins' },
            { key: 'healthy', label: 'Healthy' },
            { key: 'near_capacity', label: 'Near Capacity' },
            { key: 'collection_required', label: 'Collection Required' },
            { key: 'environmental_warning', label: 'Environmental Warning' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setStatusFilter(tab.key)}
              className={`px-2.5 py-1 rounded text-xs font-medium border transition-colors ${
                statusFilter === tab.key
                  ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Municipal Asset Table */}
      <div className="border border-slate-200 rounded-md bg-white shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-2.5">Bin ID</th>
                <th className="px-4 py-2.5">Zone / Civic Location</th>
                <th className="px-4 py-2.5 w-44">Overall Fill</th>
                <th className="px-4 py-2.5">Compartments (D / W / E / B)</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5">Last Reading</th>
                <th className="px-4 py-2.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredBins.length > 0 ? (
                filteredBins.map((bin) => (
                  <tr key={bin.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Bin ID */}
                    <td className="px-4 py-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                      <Link to={`/bins/${bin.id}`} className="text-blue-700 hover:underline">
                        {bin.id}
                      </Link>
                    </td>

                    {/* Zone & Location */}
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">{bin.zone}</div>
                      <div className="text-[11px] text-slate-500 truncate max-w-xs">
                        {bin.locationName}
                      </div>
                    </td>

                    {/* Overall Fill with Progress Bar */}
                    <td className="px-4 py-3">
                      <div className="space-y-1">
                        <ProgressBar value={bin.overallFill} showLabel size="sm" />
                      </div>
                    </td>

                    {/* 4 Pathway Quick Breakdown */}
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 font-mono text-[11px]">
                        <span title="Dry fill" className="px-1 py-0.5 rounded bg-sky-50 text-sky-800 border border-sky-200">
                          D:{bin.compartments.dry.fillPercent}%
                        </span>
                        <span title="Wet fill" className="px-1 py-0.5 rounded bg-teal-50 text-teal-800 border border-teal-200">
                          W:{bin.compartments.wet.fillPercent}%
                        </span>
                        <span title="E-waste fill" className="px-1 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200">
                          E:{bin.compartments.ewaste.fillPercent}%
                        </span>
                        <span title="Battery fill" className="px-1 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-200">
                          B:{bin.compartments.battery.fillPercent}%
                        </span>
                      </div>
                    </td>

                    {/* Operational Status */}
                    <td className="px-4 py-3 whitespace-nowrap">
                      <StatusBadge status={bin.status} size="sm" />
                    </td>

                    {/* Last Reading */}
                    <td className="px-4 py-3 text-slate-500 whitespace-nowrap font-mono text-[11px]">
                      {bin.lastUpdated}
                    </td>

                    {/* Action */}
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <Link
                        to={`/bins/${bin.id}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-500" />
                        <span>Inspect</span>
                      </Link>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-xs text-slate-500">
                    No physical bins matched your filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
          <span>Showing {filteredBins.length} of {bins.length} monitored municipal bins</span>
          <span className="font-mono text-[11px]">Ward 07 · Zone 01-04 Asset Catalog</span>
        </div>
      </div>
    </div>
  );
};
