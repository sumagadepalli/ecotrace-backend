import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { MunicipalAlert } from '../types/alert';
import { DetectionEvent } from '../types/detection';
import { SmartBin } from '../types/bin';
import { alertsApi } from '../services/api/alertsApi';
import { wasteApi } from '../services/api/wasteApi';
import { binsApi } from '../services/api/binsApi';
import { StatusBadge } from '../components/common/StatusBadge';
import { CategoryPill } from '../components/common/CategoryPill';

export const Overview: React.FC = () => {
  const navigate = useNavigate();
  const [alerts, setAlerts] = useState<MunicipalAlert[]>([]);
  const [detections, setDetections] = useState<DetectionEvent[]>([]);
  const [bins, setBins] = useState<SmartBin[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    const [alertsData, detectionsData, binsData] = await Promise.all([
      alertsApi.getAlerts(),
      wasteApi.getDetections(),
      binsApi.getBins(),
    ]);
    setAlerts(alertsData);
    setDetections(detectionsData);
    setBins(binsData);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const activeAlerts = alerts.filter((a) => a.status === 'open' || a.status === 'acknowledged');
  const criticalCount = activeAlerts.filter((a) => a.severity === 'critical').length;
  const warningCount = activeAlerts.filter((a) => a.severity === 'warning').length;

  const binsNeedingAttention = bins.filter(
    (b) => b.status === 'collection_required' || b.status === 'environmental_warning'
  ).length;

  const collectionRequiredCount = bins.filter((b) => b.status === 'collection_required').length;
  const environmentalWarningCount = bins.filter((b) => b.status === 'environmental_warning').length;

  return (
    <div className="space-y-6">
      {/* Page Heading */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">Overview</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Current operational status of your BrunoxBin network.
        </p>
      </div>

      {/* SECTION 1: ATTENTION REQUIRED (Must be prominently visible first) */}
      <section aria-labelledby="attention-heading">
        <div className="border border-slate-300 rounded-md bg-white shadow-xs overflow-hidden">
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 relative">
                {criticalCount > 0 ? (
                  <>
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600"></span>
                  </>
                ) : (
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                )}
              </span>
              <h2 id="attention-heading" className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Attention Required ({activeAlerts.length})
              </h2>
            </div>
            <Link
              to="/alerts"
              className="text-xs font-medium text-blue-700 hover:text-blue-900 inline-flex items-center gap-1"
            >
              <span>Manage all alerts</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {activeAlerts.length > 0 ? (
            <div className="divide-y divide-slate-100">
              {activeAlerts.map((alert) => {
                const isCritical = alert.severity === 'critical';
                return (
                  <div
                    key={alert.id}
                    className={`p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 transition-colors ${
                      isCritical ? 'bg-red-50/40 hover:bg-red-50/70' : 'bg-amber-50/20 hover:bg-amber-50/50'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="pt-0.5">
                        <StatusBadge status={alert.severity} size="sm" />
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            {alert.headline}
                          </span>
                          <span className="text-slate-300">·</span>
                          <Link
                            to={`/bins/${alert.binId}`}
                            className="font-mono text-xs font-semibold text-blue-700 hover:underline inline-flex items-center gap-0.5"
                          >
                            <span>Bin: {alert.binId}</span>
                            <ExternalLink className="w-3 h-3" />
                          </Link>
                        </div>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed max-w-2xl">
                          {alert.description}
                        </p>
                        <div className="mt-1.5 flex items-center gap-3 text-[11px] text-slate-500 font-mono">
                          <span>Observed: {alert.observedValue}</span>
                          <span>·</span>
                          <span>Threshold: {alert.thresholdValue}</span>
                          <span>·</span>
                          <span>Zone: {alert.zone}</span>
                          <span>·</span>
                          <span>{alert.timestamp}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                      <Link
                        to={`/bins/${alert.binId}`}
                        className="px-2.5 py-1 text-xs font-medium rounded border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 shadow-2xs"
                      >
                        View Bin
                      </Link>
                      <Link
                        to="/alerts"
                        className="px-2.5 py-1 text-xs font-medium rounded bg-blue-700 hover:bg-blue-800 text-white shadow-2xs"
                      >
                        Inspect Alert
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-6 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>All monitored bins are currently operating within configured thresholds.</span>
            </div>
          )}
        </div>
      </section>

      {/* SECTION 2: COMPACT OPERATIONAL METRICS (Not giant cards!) */}
      <section aria-labelledby="metrics-heading">
        <h2 id="metrics-heading" className="sr-only">Operational Summary Metrics</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="border border-slate-200 rounded-md bg-white p-3.5">
            <div className="text-[11px] text-slate-500 font-medium">Active Bins</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-slate-900">{bins.length}</span>
              <span className="text-[11px] text-emerald-700 font-medium">100% online</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Telemetry heartbeat normal</div>
          </div>

          <div className="border border-slate-200 rounded-md bg-white p-3.5">
            <div className="text-[11px] text-slate-500 font-medium">Needing Attention</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-amber-700">
                {binsNeedingAttention}
              </span>
              <span className="text-[11px] text-slate-500">bins</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Requires municipal action</div>
          </div>

          <div className="border border-slate-200 rounded-md bg-white p-3.5">
            <div className="text-[11px] text-slate-500 font-medium">Collection Required</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-amber-800">
                {collectionRequiredCount}
              </span>
              <span className="text-[11px] text-slate-500">&gt; 85% capacity</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Dispatch vehicle ready</div>
          </div>

          <div className="border border-slate-200 rounded-md bg-white p-3.5">
            <div className="text-[11px] text-slate-500 font-medium">Environmental Warnings</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className={`text-2xl font-bold font-mono ${environmentalWarningCount > 0 ? 'text-red-700' : 'text-slate-900'}`}>
                {environmentalWarningCount}
              </span>
              <span className="text-[11px] text-slate-500">DHT11 thresholds</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Temp &amp; humidity breaches</div>
          </div>
        </div>
      </section>

      {/* SECTION 3: RECENT WASTE INTELLIGENCE (Compact, normal table) */}
      <section aria-labelledby="waste-heading">
        <div className="border border-slate-200 rounded-md bg-white shadow-xs overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 id="waste-heading" className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Recent Waste Intelligence
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Latest classified events across physical bin pathways
              </p>
            </div>
            <Link
              to="/waste-intelligence"
              className="text-xs font-medium text-blue-700 hover:text-blue-900 inline-flex items-center gap-1"
            >
              <span>View all records</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-4 py-2.5">Time</th>
                  <th className="px-4 py-2.5">Bin ID</th>
                  <th className="px-4 py-2.5">Pathway</th>
                  <th className="px-4 py-2.5">Detected Category</th>
                  <th className="px-4 py-2.5">Confidence</th>
                  <th className="px-4 py-2.5">Status</th>
                  <th className="px-4 py-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {detections.slice(0, 5).map((evt) => (
                  <tr key={evt.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3 font-mono text-slate-600 whitespace-nowrap">
                      {evt.timestamp}
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-blue-700">
                      <Link to={`/bins/${evt.binId}`} className="hover:underline">
                        {evt.binId}
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <CategoryPill pathway={evt.wasteType} />
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900">
                      {evt.detectedCategory}
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-600">
                      {evt.confidencePercent}%
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={evt.status} size="sm" />
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Link
                        to={`/waste-intelligence/${evt.id}`}
                        className="font-medium text-blue-700 hover:text-blue-900 hover:underline"
                      >
                        Inspect
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};
