import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Search,
  Filter,
  Truck,
  ShieldCheck,
  CheckCircle2,
  Navigation,
  Info,
  MapPin,
  ExternalLink,
} from 'lucide-react';
import { RecyclingFacility } from '../types/agency';
import { SmartBin } from '../types/bin';
import { recyclingApi } from '../services/api/recyclingApi';
import { binsApi } from '../services/api/binsApi';
import { NetworkMap } from '../components/maps/NetworkMap';
import { StatusBadge } from '../components/common/StatusBadge';
import { CategoryPill } from '../components/common/CategoryPill';
import { Modal } from '../components/common/Modal';
import { RecommendationBasisCard } from '../components/intelligence/RecommendationBasis';

export const RecyclingNetwork: React.FC = () => {
  const [searchParams] = useSearchParams();
  const initialBinId = searchParams.get('bin') || 'ECO-PN-HH-0001';
  const initialFacId = searchParams.get('facility') || 'FAC-PN-001';

  const [bins, setBins] = useState<SmartBin[]>([]);
  const [selectedBinId, setSelectedBinId] = useState<string>(initialBinId);
  const [facilities, setFacilities] = useState<RecyclingFacility[]>([]);
  const [selectedFacilityId, setSelectedFacilityId] = useState<string>(initialFacId);
  const [pathwayFilter, setPathwayFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [inspectModalOpen, setInspectModalOpen] = useState(false);

  useEffect(() => {
    const loadNetworkData = async () => {
      setLoading(true);
      const [binsData, facsData] = await Promise.all([
        binsApi.getBins(),
        recyclingApi.getFacilities(),
      ]);
      setBins(binsData);
      setFacilities(facsData);
      setLoading(false);
    };
    loadNetworkData();
  }, []);

  const activeBin = bins.find((b) => b.id === selectedBinId) || bins[0];

  // Filter facilities by pathway
  const filteredFacilities = facilities.filter((fac) => {
    if (pathwayFilter === 'all') return true;
    return fac.acceptedPathways.includes(pathwayFilter as any);
  });

  // Sort by Nearest Suitable (Recommended first, then distance)
  const sortedFacilities = [...filteredFacilities].sort((a, b) => {
    if (a.priorityForDetection === 'Recommended') return -1;
    if (b.priorityForDetection === 'Recommended') return 1;
    return (a.distanceFromSelectedKm || 99) - (b.distanceFromSelectedKm || 99);
  });

  const selectedFacility = facilities.find((f) => f.id === selectedFacilityId) || sortedFacilities[0];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">Recycling Network</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Find suitable recycling facilities for recorded waste events.
        </p>
      </div>

      {/* Top Filter Bar */}
      <div className="bg-white p-3 rounded-md border border-slate-200 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Active Reference Bin Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-700 whitespace-nowrap flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-blue-600" />
            Dispatch From Bin:
          </span>
          <select
            value={selectedBinId}
            onChange={(e) => setSelectedBinId(e.target.value)}
            className="text-xs font-mono font-medium rounded border border-slate-300 px-2.5 py-1.5 bg-white text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-600"
          >
            {bins.map((b) => (
              <option key={b.id} value={b.id}>
                {b.id} ({b.zone} - Fill {b.overallFill}%)
              </option>
            ))}
          </select>
        </div>

        {/* Waste Pathway Filter */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-[11px] font-medium text-slate-500 mr-1">Waste Pathway:</span>
          {[
            { key: 'all', label: 'All' },
            { key: 'ewaste', label: 'E-Waste' },
            { key: 'battery', label: 'Battery' },
            { key: 'dry', label: 'Dry' },
            { key: 'wet', label: 'Wet' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setPathwayFilter(tab.key)}
              className={`px-2.5 py-1 rounded text-xs font-medium border transition-colors ${
                pathwayFilter === tab.key
                  ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Operational Note on Sorting */}
      <div className="px-3.5 py-2 rounded bg-blue-50/70 border border-blue-200 text-xs text-blue-900 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-blue-600 shrink-0" />
          <span>
            <span className="font-semibold">Nearest Suitable Protocol: </span>
            Facilities are prioritized by verified regulatory authorization and accepted material stream first, and geographic route distance second.
          </span>
        </div>
      </div>

      {/* Main Dual-Pane Layout: LEFT MAP | RIGHT AGENCY LIST */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[560px]">
        {/* LEFT: Operational Map (7 cols on lg) */}
        <div className="lg:col-span-7 flex flex-col h-full min-h-[440px]">
          {activeBin && (
            <NetworkMap
              bin={activeBin}
              facilities={sortedFacilities}
              selectedFacilityId={selectedFacilityId}
              onSelectFacility={(id) => setSelectedFacilityId(id)}
            />
          )}
        </div>

        {/* RIGHT: Agency List (5 cols on lg) */}
        <div className="lg:col-span-5 flex flex-col space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Eligible Facilities ({sortedFacilities.length})
            </h2>
            <span className="text-[11px] text-slate-500">
              Ranked by Suitability
            </span>
          </div>

          <div className="space-y-2.5 overflow-y-auto max-h-[580px] pr-1">
            {sortedFacilities.map((facility) => {
              const isSelected = facility.id === selectedFacilityId;
              const isRecommended = facility.priorityForDetection === 'Recommended';

              return (
                <div
                  key={facility.id}
                  onClick={() => setSelectedFacilityId(facility.id)}
                  className={`p-4 rounded-md border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/30 shadow-xs ring-1 ring-blue-600'
                      : isRecommended
                      ? 'border-emerald-300 bg-emerald-50/20 hover:bg-emerald-50/40'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-slate-900">
                          {facility.name}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {facility.address}
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1">
                      {isRecommended ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-700 text-white uppercase tracking-wider">
                          ★ Recommended
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200">
                          Eligible
                        </span>
                      )}
                      <span className="font-mono text-xs font-semibold text-slate-700">
                        {facility.distanceFromSelectedKm} km
                      </span>
                    </div>
                  </div>

                  <div className="mt-2 text-xs text-slate-600">
                    <span className="text-slate-500">Accepts: </span>
                    <span className="font-medium text-slate-800">
                      {facility.acceptedCategories.slice(0, 3).join(' · ')}
                    </span>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1 text-[11px] text-emerald-800 font-medium">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{facility.authority}</span>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedFacilityId(facility.id);
                        setInspectModalOpen(true);
                      }}
                      className="text-xs font-semibold text-blue-700 hover:text-blue-900 underline underline-offset-2"
                    >
                      Why this facility?
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* MODAL: WHY THIS AGENCY? / RECOMMENDATION BASIS */}
      {selectedFacility && (
        <Modal
          isOpen={inspectModalOpen}
          onClose={() => setInspectModalOpen(false)}
          title={selectedFacility.name}
          subtitle={`License: ${selectedFacility.licenseNumber} · ${selectedFacility.authority}`}
          maxWidth="lg"
        >
          <div className="space-y-4">
            <RecommendationBasisCard
              basis={selectedFacility.recommendationBasis}
              agencyName={selectedFacility.name}
              facilityAddress={selectedFacility.address}
              contactPhone={selectedFacility.contactPhone}
            />

            <div className="border border-slate-200 rounded p-3 bg-slate-50 text-xs text-slate-600 space-y-1">
              <div className="font-semibold text-slate-800">Facility Operations Contact</div>
              <div>Coordinator: {selectedFacility.contactPerson}</div>
              <div>Dispatch Line: {selectedFacility.contactPhone}</div>
              <div>Monthly Processing Capacity: {selectedFacility.processingCapacityTonsMonth} metric tons</div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setInspectModalOpen(false)}
                className="px-4 py-2 rounded bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold"
              >
                Close Explanation
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
