import React from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Trash2,
  Layers,
  Search,
  Truck,
  FileText,
} from 'lucide-react';

export const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-white text-slate-800 flex flex-col">
      {/* Top Municipal Bar */}
      <header className="border-b border-slate-200 bg-slate-50 px-6 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-blue-700 flex items-center justify-center text-white font-bold text-sm">
            B
          </div>
          <div>
            <span className="font-bold text-base tracking-tight text-slate-900">
              BRUNOXBIN
            </span>
            <span className="hidden sm:inline-block ml-2 text-xs text-slate-500 font-medium border-l border-slate-300 pl-2">
              Municipal Waste Infrastructure & Operations
            </span>
          </div>
        </div>

        <Link
          to="/login"
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold shadow-xs focus:outline-hidden focus:ring-2 focus:ring-blue-600 transition-colors"
        >
          <span>Municipal Login</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </header>

      {/* Hero Section */}
      <section className="max-w-4xl mx-auto px-6 pt-16 pb-12 text-center">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-medium text-slate-700 mb-6">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-700" />
          <span>Authorized Municipal Operations Platform</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 mb-4 max-w-2xl mx-auto leading-tight">
          Municipal waste monitoring and e-waste intelligence.
        </h1>

        <p className="text-base text-slate-600 max-w-2xl mx-auto leading-relaxed mb-8">
          Monitor smart bins, understand recorded e-waste events, identify suitable recycling pathways, and maintain an evidence-linked operational record.
        </p>

        <div className="flex justify-center">
          <Link
            to="/login"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold shadow-xs focus:outline-hidden focus:ring-2 focus:ring-blue-600 transition-colors"
          >
            <span>Access Operations Console</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Process Flow */}
      <section className="max-w-5xl mx-auto px-6 py-10 w-full">
        <div className="border border-slate-200 rounded-lg p-6 bg-slate-50/70">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4 text-center">
            Operational Lifecycle
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-center">
            <div className="border border-slate-200 rounded bg-white p-3.5">
              <div className="w-7 h-7 rounded bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs mx-auto mb-2">
                1
              </div>
              <div className="font-semibold text-xs text-slate-900">Detect</div>
              <p className="text-[11px] text-slate-500 mt-1">Optical & weight triggers at bin chamber</p>
            </div>

            <div className="border border-slate-200 rounded bg-white p-3.5">
              <div className="w-7 h-7 rounded bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs mx-auto mb-2">
                2
              </div>
              <div className="font-semibold text-xs text-slate-900">Classify</div>
              <p className="text-[11px] text-slate-500 mt-1">Categorization into waste pathways</p>
            </div>

            <div className="border border-slate-200 rounded bg-white p-3.5">
              <div className="w-7 h-7 rounded bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs mx-auto mb-2">
                3
              </div>
              <div className="font-semibold text-xs text-slate-900">Understand</div>
              <p className="text-[11px] text-slate-500 mt-1">Grounded material & hazard intelligence</p>
            </div>

            <div className="border border-slate-200 rounded bg-white p-3.5">
              <div className="w-7 h-7 rounded bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs mx-auto mb-2">
                4
              </div>
              <div className="font-semibold text-xs text-slate-900">Route</div>
              <p className="text-[11px] text-slate-500 mt-1">Nearest suitable verified facility</p>
            </div>

            <div className="border border-slate-200 rounded bg-white p-3.5">
              <div className="w-7 h-7 rounded bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs mx-auto mb-2">
                5
              </div>
              <div className="font-semibold text-xs text-slate-900">Record</div>
              <p className="text-[11px] text-slate-500 mt-1">Auditable municipal chain-of-custody</p>
            </div>
          </div>
        </div>
      </section>

      {/* 4 Waste Pathways */}
      <section className="max-w-5xl mx-auto px-6 py-10 w-full">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-center mb-6">
          Four Physical Waste Pathways
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="border border-slate-200 rounded-md p-4 bg-white">
            <div className="text-xs font-bold font-mono uppercase tracking-wider text-sky-800 bg-sky-50 px-2 py-0.5 rounded inline-block mb-2">
              Dry Pathway
            </div>
            <h3 className="font-semibold text-sm text-slate-900 mb-1">Recyclable Dry Waste</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Paper, cardboard, rigid polymers, and dry recyclables routed to civic aggregation depots.
            </p>
          </div>

          <div className="border border-slate-200 rounded-md p-4 bg-white">
            <div className="text-xs font-bold font-mono uppercase tracking-wider text-teal-800 bg-teal-50 px-2 py-0.5 rounded inline-block mb-2">
              Wet Pathway
            </div>
            <h3 className="font-semibold text-sm text-slate-900 mb-1">Biodegradable Organic</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Compostable organics and food waste monitored for headspace biogas accumulation.
            </p>
          </div>

          <div className="border border-slate-200 rounded-md p-4 bg-white">
            <div className="text-xs font-bold font-mono uppercase tracking-wider text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded inline-block mb-2">
              E-Waste Pathway
            </div>
            <h3 className="font-semibold text-sm text-slate-900 mb-1">Electronics & PCBs</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Circuit boards and small electronics paired with metallurgical recovery intelligence.
            </p>
          </div>

          <div className="border border-slate-200 rounded-md p-4 bg-white">
            <div className="text-xs font-bold font-mono uppercase tracking-wider text-amber-900 bg-amber-50 px-2 py-0.5 rounded inline-block mb-2">
              Battery Pathway
            </div>
            <h3 className="font-semibold text-sm text-slate-900 mb-1">Batteries & Hazardous</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Isolated chamber with environmental threshold monitoring and authorized hazardous routing.
            </p>
          </div>
        </div>
      </section>

      {/* Traceability Explanation */}
      <section className="max-w-4xl mx-auto px-6 py-10 w-full">
        <div className="border border-slate-200 rounded-lg p-6 bg-slate-50 text-slate-700 text-xs sm:text-sm leading-relaxed text-center">
          <p className="font-medium text-slate-900 mb-2">
            The Traceability Standard
          </p>
          <p className="text-slate-600 max-w-2xl mx-auto">
            BrunoxBin connects a recorded waste event to its bin, relevant intelligence, suitable recycling facilities, alerts, and operational history. Every recommendation is grounded in verified authority records without unverified claims.
          </p>
          <div className="mt-5">
            <Link
              to="/login"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors"
            >
              <span>Municipal Staff Sign In</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-slate-50 px-6 py-4 text-center text-xs text-slate-500">
        BrunoxBin · Municipal Waste Infrastructure & E-Waste Operations Platform · Internal Administrative Use
      </footer>
    </div>
  );
};
