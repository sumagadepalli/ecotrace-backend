import React, { useState } from 'react';
import {
  ShieldCheck,
  Sliders,
  Database,
  Download,
  Save,
  CheckCircle2,
  Building,
  User,
  Radio,
} from 'lucide-react';
import { mockStore } from '../services/mock/mockStorage';

export const AdminSettings: React.FC = () => {
  const [tempWarning, setTempWarning] = useState('38.0');
  const [tempCritical, setTempCritical] = useState('45.0');
  const [humidityThreshold, setHumidityThreshold] = useState('75');
  const [fillThreshold, setFillThreshold] = useState('85');
  const [syncInterval, setSyncInterval] = useState('15');
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleExportAudit = () => {
    const alerts = mockStore.getAlerts();
    const detections = mockStore.getDetections();
    const data = {
      exportTimestamp: new Date().toISOString(),
      organization: 'Pune Municipal Corporation',
      ward: 'Ward 07',
      totalAlerts: alerts.length,
      alerts,
      detections,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `brunoxbin-municipal-audit-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-slate-900">Settings &amp; Audit Logs</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Configure sensor limits, review authorized municipal authority profiles, and export operational custody logs.
        </p>
      </div>

      {saved && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 rounded text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Operational parameters updated. Telemetry threshold rules updated across active gateway.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Sensor Limits Configuration */}
        <div className="lg:col-span-2 space-y-6">
          <form onSubmit={handleSave} className="border border-slate-200 rounded-md bg-white p-5 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Sliders className="w-4 h-4 text-blue-700" />
              <h2 className="text-sm font-semibold text-slate-900">
                Configured Telemetry Thresholds
              </h2>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Define operational limits for bin hardware. When physical readings cross these thresholds, the system raises attention indicators and dispatches notifications to zonal staff.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Battery Compartment Temp Warning (°C)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={tempWarning}
                  onChange={(e) => setTempWarning(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">Default: 38.0°C</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Battery Compartment Temp Critical (°C)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={tempCritical}
                  onChange={(e) => setTempCritical(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">Critical Action Limit: 45.0°C</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Battery Humidity Warning Threshold (%)
                </label>
                <input
                  type="number"
                  value={humidityThreshold}
                  onChange={(e) => setHumidityThreshold(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">Relative Humidity Cap: 75%</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Collection Dispatch Fill Level (%)
                </label>
                <input
                  type="number"
                  value={fillThreshold}
                  onChange={(e) => setFillThreshold(e.target.value)}
                  className="w-full text-xs font-mono px-3 py-2 rounded border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-600 text-slate-900"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">Automatic Vehicle Queue: 85%</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 rounded bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Operational Thresholds</span>
              </button>
            </div>
          </form>

          {/* Audit Export Section */}
          <div className="border border-slate-200 rounded-md bg-white p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-slate-700" />
                <h2 className="text-sm font-semibold text-slate-900">
                  Municipal Chain-of-Custody &amp; Audit Logs
                </h2>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Export timestamped logs of all bin telemetry heartbeats, optical classifications, recoverable material estimations, and downstream facility dispatches for official municipal regulatory filing.
            </p>

            <div className="flex items-center gap-3">
              <button
                onClick={handleExportAudit}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold shadow-2xs transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Audit Record (JSON)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Col: Municipal Authority Profile */}
        <div className="space-y-4">
          <div className="border border-slate-200 rounded-md bg-white p-5 shadow-xs text-xs space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 font-semibold text-slate-900">
              <Building className="w-4 h-4 text-blue-700" />
              <span>Municipal Organization</span>
            </div>
            <div>
              <span className="text-slate-500">Authority:</span>
              <div className="font-semibold text-slate-900">Pune Municipal Corporation (PMC)</div>
            </div>
            <div>
              <span className="text-slate-500">Department:</span>
              <div className="font-medium text-slate-800">Solid Waste Management Division</div>
            </div>
            <div>
              <span className="text-slate-500">Active Jurisdiction:</span>
              <div className="font-medium text-slate-800">Ward 07 · Central Pune Zonal Hub</div>
            </div>
            <div>
              <span className="text-slate-500">Monitored Smart Bins:</span>
              <div className="font-mono font-bold text-slate-900">12 Installed Units</div>
            </div>
          </div>

          <div className="border border-slate-200 rounded-md bg-white p-5 shadow-xs text-xs space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 font-semibold text-slate-900">
              <User className="w-4 h-4 text-blue-700" />
              <span>Active Operator Profile</span>
            </div>
            <div>
              <span className="text-slate-500">Official Name:</span>
              <div className="font-semibold text-slate-900">S. Deshmukh</div>
            </div>
            <div>
              <span className="text-slate-500">Designation:</span>
              <div className="font-medium text-slate-800">Zonal Operations Officer</div>
            </div>
            <div>
              <span className="text-slate-500">Employee ID:</span>
              <div className="font-mono text-slate-800">PMC-SWM-4102</div>
            </div>
            <div>
              <span className="text-slate-500">Security Clearance:</span>
              <div className="inline-flex items-center gap-1 font-semibold text-emerald-800 mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Level 3 (Administrative)</span>
              </div>
            </div>
          </div>

          <div className="border border-slate-200 rounded-md bg-white p-5 shadow-xs text-xs space-y-2">
            <div className="flex items-center gap-2 font-semibold text-slate-900">
              <Radio className="w-4 h-4 text-slate-600" />
              <span>Telemetry Gateway Status</span>
            </div>
            <div className="flex items-center gap-2 text-emerald-800 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
              <span>Gateway Online (LoRaWAN Channel 865 MHz)</span>
            </div>
            <p className="text-[11px] text-slate-500">
              Receiver: Shivajinagar Municipal Base Station. Ping packet rate: 99.8% reliability.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
