import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  MapPin,
  Clock,
  Truck,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  Eye,
  Calendar,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { SmartBin } from '../types/bin';
import { DetectionEvent } from '../types/detection';
import { binsApi } from '../services/api/binsApi';
import { wasteApi } from '../services/api/wasteApi';
import { StatusBadge } from '../components/common/StatusBadge';
import { CompartmentGrid } from '../components/bins/CompartmentGrid';
import { EnvironmentalCard } from '../components/bins/EnvironmentalCard';
import { RiskBanner } from '../components/bins/RiskBanner';
import { CategoryPill } from '../components/common/CategoryPill';

export const BinDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [bin, setBin] = useState<SmartBin | null>(null);
  const [events, setEvents] = useState<DetectionEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [dispatching, setDispatching] = useState(false);
  const [dispatchSuccess, setDispatchSuccess] = useState(false);

  const loadBinData = async () => {
    if (!id) return;
    setLoading(true);
    const binData = await binsApi.getBinById(id);
    if (binData) {
      setBin(binData);
      const binEvents = await wasteApi.getDetectionsByBin(id);
      setEvents(binEvents);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadBinData();
  }, [id]);

  const handleDispatchCollection = async () => {
    if (!bin) return;
    setDispatching(true);
    await binsApi.dispatchCollection(bin.id);
    await loadBinData();
    setDispatching(false);
    setDispatchSuccess(true);
    setTimeout(() => setDispatchSuccess(false), 4000);
  };

  if (loading) {
    return (
      <div className="p-12 text-center text-xs text-slate-500 font-medium">
        Loading bin infrastructure telemetry for {id}...
      </div>
    );
  }

  if (!bin) {
    return (
      <div className="space-y-4">
        <Link
          to="/bins"
          className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline font-medium"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Smart Bins
        </Link>
        <div className="border border-slate-200 rounded-md bg-white p-8 text-center text-xs text-slate-600">
          Bin record "{id}" was not found in the active municipal registry.
        </div>
      </div>
    );
  }

  const isOkay = bin.status === 'operational';
  const hasEnvironmentalIssue = bin.status === 'environmental_warning';
  const needsCollection = bin.status === 'collection_required' || bin.overallFill >= 85;

  return (
    <div className="space-y-6">
      {/* Navigation & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <Link
            to="/bins"
            className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 font-medium mb-1.5 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Smart Bins Catalog
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 font-mono">
              {bin.id}
            </h1>
            <StatusBadge status={bin.status} />
          </div>
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
            <span className="flex items-center gap-1 font-medium text-slate-700">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              {bin.zone} · {bin.locationName}
            </span>
            <span>·</span>
            <span className="font-mono text-[11px]">Installed: {bin.installedAt}</span>
            <span>·</span>
            <span className="font-mono text-[11px] text-slate-600">
              Last updated: {bin.lastUpdated}
            </span>
          </div>
        </div>

        {/* Operational Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleDispatchCollection}
            disabled={dispatching || bin.overallFill < 20}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded text-xs font-semibold shadow-xs transition-colors ${
              needsCollection
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-slate-900 hover:bg-slate-800 text-white'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>{dispatching ? 'Dispatching...' : 'Dispatch Collection'}</span>
          </button>
        </div>
      </div>

      {/* Dispatch Success Alert */}
      {dispatchSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 rounded text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            Collection vehicle dispatched successfully for bin {bin.id}. Compartments have been emptied and operational baseline restored.
          </span>
        </div>
      )}

      {/* QUESTION 1: "Is this bin okay?" (Direct Operational Answer) */}
      <div className="border border-slate-200 rounded-md bg-white p-4 shadow-xs">
        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
          Operational Diagnosis
        </div>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            {isOkay ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            ) : hasEnvironmentalIssue ? (
              <AlertOctagon className="w-6 h-6 text-red-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
            )}
            <div>
              <div className="text-base font-bold text-slate-900">
                {isOkay
                  ? 'All compartments and environmental readings are currently within normal thresholds.'
                  : hasEnvironmentalIssue
                  ? 'Environmental warning requires technical inspection.'
                  : 'Capacity threshold breached. Immediate collection dispatch required.'}
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Overall bin capacity is at <span className="font-mono font-bold">{bin.overallFill}%</span>. Hardware unit {bin.hardwareVersion}.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION: 4 COMPARTMENTS STATUS */}
      <section aria-labelledby="compartments-heading">
        <div className="flex items-center justify-between mb-3">
          <h2 id="compartments-heading" className="text-xs font-bold uppercase tracking-wider text-slate-900">
            Compartment Fill Status
          </h2>
          <span className="text-[11px] text-slate-500">
            Volumetric Ultrasonic Sensors
          </span>
        </div>
        <CompartmentGrid compartments={bin.compartments} />
      </section>

      {/* SECTION: ENVIRONMENTAL STATUS & RISK */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <EnvironmentalCard environment={bin.environment} />
        </div>
        <div className="space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-900">
            Safety Assessment
          </div>
          <RiskBanner
            status={bin.environment.riskStatus}
            explanation={bin.environment.riskExplanation}
          />
          <div className="p-3.5 border border-slate-200 rounded-md bg-white text-xs text-slate-600 space-y-2">
            <div className="font-semibold text-slate-800 flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
              <span>Threshold Logic Protocol</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-500">
              The battery chamber is equipped with a calibrated DHT11 temperature and humidity sensor. Readings reflect ambient chamber conditions. Alerts indicate configured threshold breaches requiring physical maintenance check.
            </p>
          </div>
        </div>
      </div>

      {/* SECTION: RECENT WASTE EVENTS RECORDED AT THIS BIN */}
      <section aria-labelledby="events-heading">
        <div className="border border-slate-200 rounded-md bg-white shadow-xs overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 id="events-heading" className="text-xs font-bold uppercase tracking-wider text-slate-900">
                Recent Waste Events Recorded at {bin.id}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Physical chamber optical classifications and timestamp logs
              </p>
            </div>
            <Link
              to={`/recycling-network?bin=${bin.id}`}
              className="text-xs font-medium text-blue-700 hover:text-blue-900 inline-flex items-center gap-1"
            >
              <span>View Route on Map</span>
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-4 py-2.5">Time</th>
                  <th className="px-4 py-2.5">Pathway</th>
                  <th className="px-4 py-2.5">Detected Object</th>
                  <th className="px-4 py-2.5">Confidence</th>
                  <th className="px-4 py-2.5">Intelligence Status</th>
                  <th className="px-4 py-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {events.length > 0 ? (
                  events.map((evt) => (
                    <tr key={evt.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-4 py-3 font-mono text-slate-600 whitespace-nowrap">
                        {evt.timestamp}
                      </td>
                      <td className="px-4 py-3">
                        <CategoryPill pathway={evt.wasteType} />
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-900">
                        {evt.detectedCategory}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600">
                        {evt.confidencePercent}%
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={evt.status} size="sm" />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Link
                          to={`/waste-intelligence/${evt.id}`}
                          className="font-medium text-blue-700 hover:text-blue-900 hover:underline inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Intelligence</span>
                        </Link>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-4 py-6 text-center text-slate-500 text-xs">
                      No waste events recorded for this bin in the current shift.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};
