import React from 'react';
import { RecoverableMaterial, KnowledgeMetadata } from '../../types/detection';
import { ProvenanceTag } from './ProvenanceTag';
import { Database, Info } from 'lucide-react';

interface MaterialEstimateProps {
  componentGroup: string;
  materials: RecoverableMaterial[];
  knowledgeBase: KnowledgeMetadata;
}

export const MaterialEstimate: React.FC<MaterialEstimateProps> = ({
  componentGroup,
  materials,
  knowledgeBase,
}) => {
  return (
    <div className="border border-slate-200 rounded-md bg-white p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-900">Material Intelligence</h3>
            <ProvenanceTag kind="ESTIMATED" />
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Component group: <span className="font-medium text-slate-700">{componentGroup}</span>
          </p>
        </div>

        {/* Grounded Source Metadata Badge */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-100 border border-slate-200 text-[11px] text-slate-600">
          <Database className="w-3.5 h-3.5 text-slate-400" />
          <span>
            {knowledgeBase.sourceName} · {knowledgeBase.version}
          </span>
        </div>
      </div>

      {/* Materials Table */}
      {materials.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-200 rounded">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="px-3 py-2">Potential Material</th>
                <th className="px-3 py-2">Estimated Yield / Fraction</th>
                <th className="px-3 py-2">Downstream Industrial Application</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {materials.map((m, idx) => (
                <tr key={idx} className="hover:bg-slate-50/60">
                  <td className="px-3 py-2.5 font-medium text-slate-900">
                    {m.name}
                  </td>
                  <td className="px-3 py-2.5 font-mono text-slate-800 font-medium">
                    {m.estimatedConcentration}
                  </td>
                  <td className="px-3 py-2.5 text-slate-600">
                    {m.potentialApplication}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="p-4 rounded border border-dashed border-slate-200 bg-slate-50 text-center text-xs text-slate-500">
          Material profile unavailable for this detection record.
        </div>
      )}

      {/* Operational Disclaimer Note */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-start gap-2 text-[11px] text-slate-500 leading-relaxed">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-slate-600">Knowledge-based estimate: </span>
          Values are statistical recovery fractions estimated from the curated municipal metallurgical knowledge base ({knowledgeBase.referenceDate}, curated by {knowledgeBase.curatorAgency}). These do not represent individual laboratory assays or destructive chemical testing.
        </div>
      </div>
    </div>
  );
};
