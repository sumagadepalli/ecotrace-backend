import React from 'react';

export type ProvenanceKind = 'DETECTED' | 'CALCULATED' | 'ESTIMATED' | 'RECOMMENDED';

interface ProvenanceTagProps {
  kind: ProvenanceKind;
  description?: string;
  className?: string;
}

export const ProvenanceTag: React.FC<ProvenanceTagProps> = ({ kind, description, className = '' }) => {
  const styles = {
    DETECTED: 'bg-blue-100 text-blue-900 border-blue-300',
    CALCULATED: 'bg-indigo-100 text-indigo-900 border-indigo-300',
    ESTIMATED: 'bg-amber-100 text-amber-900 border-amber-300',
    RECOMMENDED: 'bg-emerald-100 text-emerald-900 border-emerald-300',
  }[kind];

  return (
    <div className={`inline-flex items-center gap-1.5 ${className}`}>
      <span
        className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider uppercase border ${styles}`}
      >
        {kind}
      </span>
      {description && <span className="text-xs text-slate-600">{description}</span>}
    </div>
  );
};
