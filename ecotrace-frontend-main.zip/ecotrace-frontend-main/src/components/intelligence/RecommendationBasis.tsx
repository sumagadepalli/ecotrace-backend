import React from 'react';
import { RecommendationBasis as RecommendationBasisType } from '../../types/agency';
import { CheckCircle2, ShieldCheck, Navigation, Layers } from 'lucide-react';
import { ProvenanceTag } from './ProvenanceTag';

interface RecommendationBasisProps {
  basis?: RecommendationBasisType;
  agencyName: string;
  facilityAddress: string;
  contactPhone: string;
}

export const RecommendationBasisCard: React.FC<RecommendationBasisProps> = ({
  basis,
  agencyName,
  facilityAddress,
  contactPhone,
}) => {
  if (!basis) {
    return (
      <div className="border border-slate-200 rounded-md bg-white p-5 text-xs text-slate-500">
        Facility evaluation pending selection.
      </div>
    );
  }

  return (
    <div className="border border-slate-200 rounded-md bg-white p-5">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-900">Recommendation Basis</h3>
            <ProvenanceTag kind="RECOMMENDED" />
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Operational criteria applied to rank this facility for immediate dispatch
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        {/* Capability */}
        <div className="border border-slate-200 rounded p-3 bg-slate-50">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
            <Layers className="w-3.5 h-3.5 text-blue-600" />
            <span>Capability Match</span>
          </div>
          <div className="text-sm font-semibold text-emerald-800 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            {basis.capabilityStatus}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5 truncate" title={basis.detectedWaste}>
            Target: {basis.detectedWaste}
          </div>
        </div>

        {/* Verification */}
        <div className="border border-slate-200 rounded p-3 bg-slate-50">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Regulatory Audit</span>
          </div>
          <div className="text-sm font-semibold text-emerald-800 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            {basis.verificationStatus}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">MPCB Authorized</div>
        </div>

        {/* Distance */}
        <div className="border border-slate-200 rounded p-3 bg-slate-50">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
            <Navigation className="w-3.5 h-3.5 text-slate-500" />
            <span>Transit Distance</span>
          </div>
          <div className="text-sm font-bold font-mono text-slate-900">
            {basis.distanceKm} km
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">From reporting bin</div>
        </div>

        {/* Route Priority */}
        <div className="border border-slate-200 rounded p-3 bg-slate-50">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
            <span className="text-blue-600 font-bold text-xs">#1</span>
            <span>Route Priority</span>
          </div>
          <div className="text-xs font-semibold text-blue-900">
            Highest Ranked
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Nearest suitable facility</div>
        </div>
      </div>

      {/* Summary Explanation */}
      <div className="p-3 bg-blue-50/60 border border-blue-100 rounded text-xs text-slate-700 leading-relaxed mb-3">
        <span className="font-semibold text-blue-950">Reason for recommendation: </span>
        {basis.routePriorityText}. {basis.suitabilityScoreSummary}
      </div>

      {/* Facility Contact Details */}
      <div className="text-xs text-slate-600 flex flex-col sm:flex-row sm:items-center justify-between gap-1 pt-2 border-t border-slate-100">
        <div>
          <span className="font-medium text-slate-800">{agencyName}</span> · {facilityAddress}
        </div>
        <div className="font-mono text-slate-500">Dispatch Contact: {contactPhone}</div>
      </div>
    </div>
  );
};
