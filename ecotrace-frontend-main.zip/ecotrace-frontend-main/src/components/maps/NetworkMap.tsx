import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { SmartBin } from '../../types/bin';
import { RecyclingFacility } from '../../types/agency';

interface NetworkMapProps {
  bin: SmartBin;
  facilities: RecyclingFacility[];
  selectedFacilityId?: string;
  onSelectFacility?: (id: string) => void;
}

// Custom DivIcons with SVG to ensure markers always render crisp and never 404 on image paths
const createBinIcon = (binId: string) =>
  L.divIcon({
    className: 'custom-bin-marker',
    html: `
      <div style="
        background: #1e293b;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-family: system-ui, sans-serif;
        font-size: 11px;
        font-weight: 700;
        border: 2px solid #3b82f6;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.2);
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 4px;
      ">
        <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#60a5fa;"></span>
        ${binId}
      </div>
    `,
    iconSize: [120, 28],
    iconAnchor: [60, 14],
  });

const createFacilityIcon = (facility: RecyclingFacility, isRecommended: boolean, isSelected: boolean) => {
  const bg = isRecommended ? '#15803d' : isSelected ? '#1d4ed8' : '#475569';
  const border = isRecommended ? '#86efac' : isSelected ? '#93c5fd' : '#cbd5e1';
  const label = isRecommended ? '★ RECOMMENDED' : facility.priorityForDetection === 'Alternative' ? 'Eligible' : 'Facility';

  return L.divIcon({
    className: 'custom-facility-marker',
    html: `
      <div style="
        background: ${bg};
        color: white;
        padding: 3px 6px;
        border-radius: 4px;
        font-family: system-ui, sans-serif;
        font-size: 10px;
        font-weight: 600;
        border: 1.5px solid ${border};
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.25);
        white-space: nowrap;
      ">
        <div style="font-size:9px; opacity:0.9; text-transform:uppercase;">${label}</div>
        <div style="max-width:140px; overflow:hidden; text-overflow:ellipsis;">${facility.name}</div>
      </div>
    `,
    iconSize: [140, 36],
    iconAnchor: [70, 18],
  });
};

// Component to dynamically fit bounds of bin + facilities
const MapBoundsAdjuster: React.FC<{ bin: SmartBin; facilities: RecyclingFacility[] }> = ({
  bin,
  facilities,
}) => {
  const map = useMap();

  useEffect(() => {
    if (!map) return;
    const points: L.LatLngTuple[] = [[bin.lat, bin.lng]];
    facilities.forEach((f) => points.push([f.lat, f.lng]));
    if (points.length > 1) {
      const bounds = L.latLngBounds(points);
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 13 });
    } else {
      map.setView([bin.lat, bin.lng], 12);
    }
  }, [map, bin, facilities]);

  return null;
};

export const NetworkMap: React.FC<NetworkMapProps> = ({
  bin,
  facilities,
  selectedFacilityId,
  onSelectFacility,
}) => {
  const recommendedFacility = facilities.find((f) => f.priorityForDetection === 'Recommended');
  const activeFacility = facilities.find((f) => f.id === selectedFacilityId) || recommendedFacility;

  const routePositions: [number, number][] =
    activeFacility && bin ? [[bin.lat, bin.lng], [activeFacility.lat, activeFacility.lng]] : [];

  return (
    <div className="w-full h-full min-h-[420px] rounded-md overflow-hidden border border-slate-200 relative">
      <MapContainer
        center={[bin.lat, bin.lng]}
        zoom={12}
        scrollWheelZoom={false}
        className="w-full h-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* Adjust viewport */}
        <MapBoundsAdjuster bin={bin} facilities={facilities} />

        {/* Active Route to Facility */}
        {routePositions.length === 2 && (
          <Polyline
            positions={routePositions}
            pathOptions={{
              color: '#1d4ed8',
              weight: 3,
              dashArray: '6, 6',
              opacity: 0.8,
            }}
          />
        )}

        {/* Reporting Bin Marker */}
        <Marker position={[bin.lat, bin.lng]} icon={createBinIcon(bin.id)}>
          <Popup>
            <div className="p-2 text-xs">
              <div className="font-bold text-slate-900">{bin.id}</div>
              <div className="text-slate-600">{bin.locationName}</div>
              <div className="mt-1 font-mono text-[11px] text-blue-700">
                Overall fill: {bin.overallFill}% · {bin.status}
              </div>
            </div>
          </Popup>
        </Marker>

        {/* Recycling Facilities Markers */}
        {facilities.map((fac) => {
          const isRecommended = fac.priorityForDetection === 'Recommended';
          const isSelected = fac.id === selectedFacilityId;

          return (
            <Marker
              key={fac.id}
              position={[fac.lat, fac.lng]}
              icon={createFacilityIcon(fac, isRecommended, isSelected)}
              eventHandlers={{
                click: () => onSelectFacility && onSelectFacility(fac.id),
              }}
            >
              <Popup>
                <div className="p-2 text-xs">
                  <div className="font-bold text-slate-900">{fac.name}</div>
                  <div className="text-slate-600 text-[11px] mt-0.5">{fac.address}</div>
                  <div className="mt-1 flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-emerald-700">
                      {fac.verified ? '✓ Verified Recycler' : 'Unverified'}
                    </span>
                    <span className="font-mono text-slate-600 font-medium">
                      {fac.distanceFromSelectedKm} km
                    </span>
                  </div>
                  <div className="mt-1 text-[11px] text-slate-500">
                    Accepts: {fac.acceptedCategories.slice(0, 3).join(', ')}
                  </div>
                  {onSelectFacility && (
                    <button
                      onClick={() => onSelectFacility(fac.id)}
                      className="mt-2 w-full py-1 text-center bg-blue-600 hover:bg-blue-700 text-white rounded font-medium text-[10px]"
                    >
                      Inspect Route & Recommendation
                    </button>
                  )}
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>

      {/* Operational Map Legend Overlay */}
      <div className="absolute bottom-3 left-3 z-[1000] bg-white/95 backdrop-blur-xs border border-slate-200 rounded p-2.5 text-xs shadow-md space-y-1.5 pointer-events-auto">
        <div className="font-semibold text-[11px] text-slate-900 uppercase tracking-wider">
          Operational Map Legend
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-700">
          <span className="w-3 h-3 rounded bg-slate-900 border border-blue-400 inline-block"></span>
          <span>Reporting Smart Bin</span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-700">
          <span className="w-3 h-3 rounded bg-emerald-700 border border-emerald-300 inline-block"></span>
          <span>★ Recommended Facility (Nearest Suitable)</span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-700">
          <span className="w-3 h-3 rounded bg-slate-600 inline-block"></span>
          <span>Eligible Alternate Recycler</span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-700">
          <span className="w-4 h-0.5 border-t-2 border-dashed border-blue-600 inline-block"></span>
          <span>Transit Priority Route</span>
        </div>
      </div>
    </div>
  );
};
