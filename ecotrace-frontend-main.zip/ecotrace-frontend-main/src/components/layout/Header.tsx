import React from 'react';
import { Bell, MapPin, RefreshCw } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { mockStore } from '../../services/mock/mockStorage';

interface HeaderProps {
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onRefresh, isRefreshing = false }) => {
  const location = useLocation();
  const alerts = mockStore.getAlerts().filter((a) => a.status === 'open');
  const criticalCount = alerts.filter((a) => a.severity === 'critical').length;

  const getPageTitle = () => {
    const path = location.pathname;
    if (path.startsWith('/bins/')) return 'Bin Detail Inspection';
    if (path.startsWith('/waste-intelligence/')) return 'E-Waste Intelligence Event';
    switch (path) {
      case '/overview':
        return 'Overview';
      case '/bins':
        return 'Smart Bins';
      case '/waste-intelligence':
        return 'Waste Intelligence';
      case '/recycling-network':
        return 'Recycling Network';
      case '/alerts':
        return 'Operational Alerts';
      case '/admin':
        return 'Settings & Audit Logs';
      default:
        return 'Operations';
    }
  };

  return (
    <header className="h-14 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-20">
      <div className="flex items-center gap-3">
        <h2 className="text-sm font-semibold text-slate-800 tracking-tight">
          {getPageTitle()}
        </h2>
        <span className="text-slate-300">|</span>
        <div className="flex items-center gap-1.5 text-xs text-slate-500">
          <MapPin className="w-3.5 h-3.5 text-slate-400" />
          <span>Pune Municipal District — Solid Waste Operations Hub</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {/* Telemetry heartbeat indicator */}
        <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-slate-100 border border-slate-200 text-xs text-slate-600">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-mono text-[11px]">Telemetry Online · 12 Bins Monitored</span>
        </div>

        {/* Quick Refresh */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-1.5 rounded text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-600 transition-colors"
            title="Refresh active telemetry"
            aria-label="Refresh telemetry"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-blue-600' : ''}`} />
          </button>
        )}

        {/* Quick Alerts Link */}
        <Link
          to="/alerts"
          className="relative p-1.5 rounded text-slate-500 hover:text-slate-800 hover:bg-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-600 transition-colors"
          title="View active alerts"
          aria-label="View active alerts"
        >
          <Bell className="w-4 h-4" />
          {criticalCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-600 ring-2 ring-white" />
          )}
        </Link>
      </div>
    </header>
  );
};
