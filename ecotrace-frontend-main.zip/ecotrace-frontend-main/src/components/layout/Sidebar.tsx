import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Trash2,
  Cpu,
  Truck,
  AlertTriangle,
  Settings,
  LogOut,
  ShieldCheck,
} from 'lucide-react';
import { mockStore } from '../../services/mock/mockStorage';

export const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const alerts = mockStore.getAlerts().filter((a) => a.status === 'open' || a.status === 'acknowledged');
  const criticalCount = alerts.filter((a) => a.severity === 'critical').length;
  const warningCount = alerts.filter((a) => a.severity === 'warning').length;
  const totalActive = criticalCount + warningCount;

  const navItems = [
    { to: '/overview', label: 'Overview', icon: LayoutDashboard },
    { to: '/bins', label: 'Smart Bins', icon: Trash2 },
    { to: '/waste-intelligence', label: 'Waste Intelligence', icon: Cpu },
    { to: '/recycling-network', label: 'Recycling Network', icon: Truck },
    {
      to: '/alerts',
      label: 'Alerts',
      icon: AlertTriangle,
      badge: totalActive > 0 ? totalActive : undefined,
      hasCritical: criticalCount > 0,
    },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-200 flex flex-col shrink-0 border-r border-slate-800 min-h-screen">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800/80">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center text-white font-bold text-base shadow-xs">
            B
          </div>
          <div>
            <h1 className="font-bold text-base tracking-tight text-white leading-none">
              BRUNOXBIN
            </h1>
            <p className="text-[11px] text-slate-400 mt-1 font-medium tracking-wide uppercase">
              Municipal Operations
            </p>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          Operations Console
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`
              }
            >
              <div className="flex items-center gap-2.5">
                <Icon className="w-4 h-4 opacity-80" />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded-full font-bold ${
                    item.hasCritical
                      ? 'bg-red-600 text-white'
                      : 'bg-amber-500 text-slate-950'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </NavLink>
          );
        })}

        <div className="pt-6 px-3 pb-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          Administration
        </div>
        <NavLink
          to="/admin"
          className={({ isActive }) =>
            `flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
              isActive
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`
          }
        >
          <Settings className="w-4 h-4 opacity-80" />
          <span>Settings & Audit</span>
        </NavLink>
      </nav>

      {/* Municipal Organization & User Footer */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40 text-xs">
        <div className="px-2 py-1.5 mb-2 rounded bg-slate-800/50 border border-slate-700/50">
          <div className="flex items-center gap-1.5 text-blue-400 text-[11px] font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Authorized Operations</span>
          </div>
          <p className="text-[11px] text-slate-300 font-medium truncate mt-0.5">
            Pune Municipal Corp · Ward 07
          </p>
        </div>

        <div className="flex items-center justify-between px-2 pt-1">
          <div className="truncate">
            <div className="font-medium text-slate-200 text-xs">S. Deshmukh</div>
            <div className="text-[10px] text-slate-400 truncate">Ops Officer #4102</div>
          </div>
          <button
            onClick={() => navigate('/login')}
            title="Sign out of operations portal"
            className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 focus:outline-hidden focus:ring-1 focus:ring-slate-500"
            aria-label="Log out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
