import React from 'react';
import { PathwayType } from '../../types/bin';

interface CategoryPillProps {
  pathway: PathwayType | string;
  className?: string;
}

export const CategoryPill: React.FC<CategoryPillProps> = ({ pathway, className = '' }) => {
  const norm = pathway.toLowerCase();

  let styles = 'bg-slate-100 text-slate-700 border-slate-200';
  let label = pathway;

  if (norm === 'dry') {
    styles = 'bg-sky-50 text-sky-800 border-sky-200';
    label = 'Dry';
  } else if (norm === 'wet') {
    styles = 'bg-teal-50 text-teal-800 border-teal-200';
    label = 'Wet';
  } else if (norm === 'ewaste' || norm === 'e-waste') {
    styles = 'bg-indigo-50 text-indigo-800 border-indigo-200 font-medium';
    label = 'E-Waste';
  } else if (norm === 'battery') {
    styles = 'bg-amber-50 text-amber-900 border-amber-200 font-medium';
    label = 'Battery';
  }

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs border uppercase tracking-wider font-mono ${styles} ${className}`}
    >
      {label}
    </span>
  );
};
