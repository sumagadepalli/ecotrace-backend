import React from 'react';

interface ProgressBarProps {
  value: number; // 0 to 100
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  ariaLabel?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  showLabel = false,
  size = 'md',
  className = '',
  ariaLabel = 'Fill Level',
}) => {
  const clampedValue = Math.min(100, Math.max(0, value));

  // Determine operational fill color
  let barColor = 'bg-emerald-600';
  if (clampedValue >= 85) {
    barColor = 'bg-amber-600'; // Critical capacity alert
  } else if (clampedValue >= 70) {
    barColor = 'bg-amber-500'; // Near capacity warning
  }

  const heightClass = size === 'sm' ? 'h-1.5' : size === 'lg' ? 'h-3' : 'h-2';

  return (
    <div className={`w-full ${className}`}>
      <div className="flex items-center gap-2">
        <div
          role="progressbar"
          aria-label={ariaLabel}
          aria-valuenow={clampedValue}
          aria-valuemin={0}
          aria-valuemax={100}
          className={`flex-1 bg-slate-200 rounded-full overflow-hidden ${heightClass}`}
        >
          <div
            className={`${heightClass} ${barColor} rounded-full transition-all duration-300`}
            style={{ width: `${clampedValue}%` }}
          />
        </div>
        {showLabel && (
          <span className="text-xs font-mono font-medium text-slate-700 min-w-[32px] text-right">
            {clampedValue}%
          </span>
        )}
      </div>
    </div>
  );
};
