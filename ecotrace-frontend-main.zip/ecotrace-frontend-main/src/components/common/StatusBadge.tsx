import React from 'react';

type BadgeType =
  | 'operational'
  | 'near_capacity'
  | 'collection_required'
  | 'environmental_warning'
  | 'offline'
  | 'critical'
  | 'warning'
  | 'resolved'
  | 'open'
  | 'acknowledged'
  | 'normal'
  | 'attention'
  | 'Recommendation ready'
  | 'Recorded'
  | 'Analysis unavailable'
  | 'Verified'
  | 'Pending Audit'
  | 'Unverified';

interface StatusBadgeProps {
  status: BadgeType | string;
  size?: 'sm' | 'md';
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md', className = '' }) => {
  const norm = status?.toLowerCase() || '';

  let colorClasses = 'bg-slate-100 text-slate-700 border-slate-300';
  let icon = '';
  let label = status;

  if (norm === 'operational' || norm === 'normal') {
    colorClasses = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    icon = '●';
    label = norm === 'operational' ? 'Operational' : 'Normal';
  } else if (norm === 'near_capacity') {
    colorClasses = 'bg-amber-50 text-amber-800 border-amber-200';
    icon = '▲';
    label = 'Near capacity';
  } else if (norm === 'collection_required') {
    colorClasses = 'bg-amber-100 text-amber-900 border-amber-300 font-semibold';
    icon = '🟠';
    label = 'Collection required';
  } else if (norm === 'environmental_warning' || norm === 'warning') {
    colorClasses = 'bg-amber-50 text-amber-800 border-amber-200';
    icon = '🟠';
    label = norm === 'environmental_warning' ? 'Environmental warning' : 'Warning';
  } else if (norm === 'critical') {
    colorClasses = 'bg-red-50 text-red-800 border-red-200 font-semibold';
    icon = '🔴';
    label = 'Critical';
  } else if (norm === 'resolved') {
    colorClasses = 'bg-emerald-50 text-emerald-800 border-emerald-200';
    icon = '✓';
    label = 'Resolved';
  } else if (norm === 'open') {
    colorClasses = 'bg-red-50 text-red-800 border-red-200 font-semibold';
    icon = '●';
    label = 'Open';
  } else if (norm === 'acknowledged' || norm === 'in_progress') {
    colorClasses = 'bg-blue-50 text-blue-800 border-blue-200';
    icon = 'ℹ';
    label = norm === 'acknowledged' ? 'Acknowledged' : 'In Progress';
  } else if (norm === 'recommendation ready') {
    colorClasses = 'bg-blue-50 text-blue-800 border-blue-200 font-medium';
    icon = '✓';
    label = 'Recommendation ready';
  } else if (norm === 'recorded') {
    colorClasses = 'bg-slate-100 text-slate-700 border-slate-200';
    icon = '—';
    label = 'Recorded';
  } else if (norm === 'analysis unavailable') {
    colorClasses = 'bg-slate-100 text-slate-600 border-slate-300 italic';
    icon = '⚠';
    label = 'Analysis unavailable';
  } else if (norm === 'verified') {
    colorClasses = 'bg-emerald-50 text-emerald-800 border-emerald-200 font-medium';
    icon = '✓';
    label = 'Verified';
  }

  const padding = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded border ${padding} font-medium ${colorClasses} ${className}`}
    >
      <span className="text-[10px] leading-none" aria-hidden="true">{icon}</span>
      <span>{label}</span>
    </span>
  );
};
