import React from 'react';
import { CompartmentStatus } from '../../types/bin';
import { ProgressBar } from '../common/ProgressBar';
import { CategoryPill } from '../common/CategoryPill';
import { StatusBadge } from '../common/StatusBadge';

interface CompartmentGridProps {
  compartments: {
    dry: CompartmentStatus;
    wet: CompartmentStatus;
    ewaste: CompartmentStatus;
    battery: CompartmentStatus;
  };
}

export const CompartmentGrid: React.FC<CompartmentGridProps> = ({ compartments }) => {
  const items = [
    { key: 'dry', comp: compartments.dry },
    { key: 'wet', comp: compartments.wet },
    { key: 'ewaste', comp: compartments.ewaste },
    { key: 'battery', comp: compartments.battery },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {items.map(({ key, comp }) => {
        const isNearCapacity = comp.fillPercent >= 85;
        return (
          <div
            key={key}
            className={`border rounded-md p-4 bg-white ${
              isNearCapacity ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <CategoryPill pathway={comp.pathway} />
              <StatusBadge
                status={comp.status === 'critical' ? 'collection_required' : comp.status}
                size="sm"
              />
            </div>

            <div className="mb-2 flex items-baseline justify-between">
              <span className="text-xs text-slate-500 font-medium">Volumetric Fill</span>
              <span className="text-lg font-bold font-mono text-slate-900">
                {comp.fillPercent}%
              </span>
            </div>

            <ProgressBar value={comp.fillPercent} size="md" />

            <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
              <span>Last emptied:</span>
              <span className="font-mono text-slate-600">{comp.lastEmptyTimestamp}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
};
