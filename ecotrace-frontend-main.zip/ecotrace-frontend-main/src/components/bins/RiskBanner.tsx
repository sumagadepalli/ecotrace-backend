import React from 'react';
import { ShieldCheck, AlertTriangle, AlertOctagon } from 'lucide-react';

interface RiskBannerProps {
  status: 'normal' | 'warning' | 'critical';
  explanation: string;
}

export const RiskBanner: React.FC<RiskBannerProps> = ({ status, explanation }) => {
  if (status === 'critical') {
    return (
      <div className="border border-red-300 bg-red-50/80 rounded-md p-4 text-red-900 flex items-start gap-3">
        <AlertOctagon className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm">Environmental Risk: Critical</span>
            <span className="text-xs bg-red-200/80 text-red-800 font-semibold px-2 py-0.5 rounded">
              Action Required
            </span>
          </div>
          <p className="text-xs text-red-800 mt-1 leading-relaxed">{explanation}</p>
          <div className="mt-2 text-[11px] text-red-700">
            Note: Triggered by configured DHT11 temperature limit threshold. Field inspection dispatched.
          </div>
        </div>
      </div>
    );
  }

  if (status === 'warning') {
    return (
      <div className="border border-amber-300 bg-amber-50/80 rounded-md p-4 text-amber-900 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm">Environmental Risk: Warning</span>
            <span className="text-xs bg-amber-200/80 text-amber-800 font-semibold px-2 py-0.5 rounded">
              Attention Required
            </span>
          </div>
          <p className="text-xs text-amber-800 mt-1 leading-relaxed">{explanation}</p>
          <div className="mt-2 text-[11px] text-amber-700">
            Note: Threshold-based environmental condition. Sensor readings require scheduled maintenance review.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="border border-emerald-200 bg-emerald-50/50 rounded-md p-3.5 text-emerald-900 flex items-center justify-between">
      <div className="flex items-center gap-2.5">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
        <div>
          <span className="font-semibold text-xs text-emerald-900">Environmental Risk: Normal</span>
          <p className="text-xs text-emerald-800 mt-0.5">{explanation}</p>
        </div>
      </div>
      <span className="text-[11px] text-emerald-700 font-medium px-2 py-0.5 bg-emerald-100/60 rounded">
        All Sensors In Threshold
      </span>
    </div>
  );
};
