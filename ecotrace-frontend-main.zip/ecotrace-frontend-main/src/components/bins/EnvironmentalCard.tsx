import React from 'react';
import { EnvironmentalReadings } from '../../types/bin';
import { StatusBadge } from '../common/StatusBadge';
import { Thermometer, Droplets, Wind, AlertCircle } from 'lucide-react';

interface EnvironmentalCardProps {
  environment: EnvironmentalReadings;
}

export const EnvironmentalCard: React.FC<EnvironmentalCardProps> = ({ environment }) => {
  const {
    batteryCompartmentTemp,
    batteryCompartmentHumidity,
    wetCompartmentGasIndex,
    lastPingTimestamp,
    sensorModel,
  } = environment;

  const tempStatus =
    batteryCompartmentTemp === null
      ? 'No recent reading'
      : batteryCompartmentTemp >= 45
      ? 'critical'
      : batteryCompartmentTemp >= 38
      ? 'warning'
      : 'normal';

  const humidityStatus =
    batteryCompartmentHumidity === null
      ? 'No recent reading'
      : batteryCompartmentHumidity >= 75
      ? 'warning'
      : 'normal';

  return (
    <div className="border border-slate-200 rounded-md bg-white p-5">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">Environmental Telemetry</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Sensor package: {sensorModel} · Last reading: {lastPingTimestamp || 'No recent reading'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Battery Temperature */}
        <div className="border border-slate-200 rounded p-3.5 bg-slate-50/50">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="flex items-center gap-1.5 font-medium">
              <Thermometer className="w-4 h-4 text-slate-400" />
              Battery Temp
            </span>
            {batteryCompartmentTemp !== null ? (
              <StatusBadge status={tempStatus} size="sm" />
            ) : (
              <span className="text-xs text-slate-500 italic">No reading</span>
            )}
          </div>
          <div className="flex items-baseline gap-1.5">
            {batteryCompartmentTemp !== null ? (
              <>
                <span className="text-2xl font-bold font-mono text-slate-900">
                  {batteryCompartmentTemp}
                </span>
                <span className="text-xs font-semibold text-slate-600">°C</span>
              </>
            ) : (
              <span className="text-sm font-medium text-slate-500 italic">
                No recent reading
              </span>
            )}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            Threshold: Warning &gt; 38°C · Critical &gt; 45°C
          </div>
        </div>

        {/* Battery Humidity */}
        <div className="border border-slate-200 rounded p-3.5 bg-slate-50/50">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="flex items-center gap-1.5 font-medium">
              <Droplets className="w-4 h-4 text-slate-400" />
              Battery Humidity
            </span>
            {batteryCompartmentHumidity !== null ? (
              <StatusBadge status={humidityStatus} size="sm" />
            ) : (
              <span className="text-xs text-slate-500 italic">No reading</span>
            )}
          </div>
          <div className="flex items-baseline gap-1.5">
            {batteryCompartmentHumidity !== null ? (
              <>
                <span className="text-2xl font-bold font-mono text-slate-900">
                  {batteryCompartmentHumidity}
                </span>
                <span className="text-xs font-semibold text-slate-600">% RH</span>
              </>
            ) : (
              <span className="text-sm font-medium text-slate-500 italic">
                No recent reading
              </span>
            )}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            Threshold: Warning &gt; 75% RH
          </div>
        </div>

        {/* Wet Compartment Gas Index */}
        <div className="border border-slate-200 rounded p-3.5 bg-slate-50/50">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="flex items-center gap-1.5 font-medium">
              <Wind className="w-4 h-4 text-slate-400" />
              Wet Gas Index
            </span>
            {wetCompartmentGasIndex !== null ? (
              <StatusBadge status={wetCompartmentGasIndex} size="sm" />
            ) : (
              <span className="text-xs text-slate-500 italic">No reading</span>
            )}
          </div>
          <div className="flex items-baseline gap-1.5">
            {wetCompartmentGasIndex !== null ? (
              <span className="text-lg font-semibold text-slate-800 capitalize">
                {wetCompartmentGasIndex}
              </span>
            ) : (
              <span className="text-sm font-medium text-slate-500 italic">
                No recent reading
              </span>
            )}
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            Biogas headspace threshold monitor
          </div>
        </div>
      </div>

      {/* Sensor note */}
      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-1.5 text-[11px] text-slate-500">
        <AlertCircle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <span>
          Telemetry readings are transmitted via regional LoRaWAN/NB-IoT municipal network on 15-minute sync intervals.
        </span>
      </div>
    </div>
  );
};
